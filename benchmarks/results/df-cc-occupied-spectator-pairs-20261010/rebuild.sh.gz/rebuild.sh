#!/usr/bin/env bash
set -euo pipefail
root=/data/jzzeng/qc-cc-spectator-pairs-20261010
deps=/data/jzzeng/issue1972-20261005/deps
export PATH="$deps/bin:/group/software/cuda-12.9.1/bin:/usr/bin:/home/jzzeng/miniconda3/bin:$PATH"
export LD_LIBRARY_PATH="$deps/lib:/group/software/cuda-12.9.1/lib64:${LD_LIBRARY_PATH:-}"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export CCACHE_BASEDIR="$root/production-source"
if [[ ! -f "$root/pilot-admission-binaries.sha256" ]]; then
  cp "$root/candidate-admission/binaries.sha256" "$root/pilot-admission-binaries.sha256"
fi
tar -xzf "$root/admission-overlay-v3.tar.gz" -C "$root/production-source"
cd "$root/production-source"
cmake --build build-cuda --target generativeqc -j8 > "$root/candidate-admission/build-v3.log" 2>&1
cp build-cuda/libgenerativeqc.so "$root/candidate-admission/"
cp -a build-cuda/generated "$root/candidate-admission/"
sha256sum "$root/candidate-admission/libgenerativeqc.so" "$root/candidate-admission/endpoint" \
  > "$root/candidate-admission/binaries.sha256"
