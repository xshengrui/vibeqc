#!/usr/bin/env bash
set -euo pipefail
root=/data/jzzeng/qc-cc-spectator-pairs-20261010
deps=/data/jzzeng/issue1972-20261005/deps
export PATH="$deps/bin:/group/software/cuda-12.9.1/bin:/usr/bin:/home/jzzeng/miniconda3/bin:$PATH"
export LD_LIBRARY_PATH="$root/candidate-admission:$deps/lib:/group/software/cuda-12.9.1/lib64:${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$root/production-source/python:$root/production-source:$deps"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
cd "$root/production-source"
printf '%s\n' "$SLURM_JOB_ID" "$CUDA_VISIBLE_DEVICES" > "$root/measure-admission-allocation.txt"
/home/jzzeng/miniconda3/bin/python "$root/measure-admission.py" \
  > "$root/final-admission-measure.log" 2>&1
