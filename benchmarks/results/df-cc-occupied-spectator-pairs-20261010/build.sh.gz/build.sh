#!/usr/bin/env bash
set -euo pipefail
root=/data/jzzeng/qc-cc-spectator-pairs-20261010
deps=/data/jzzeng/issue1972-20261005/deps
export PATH="$deps/bin:/group/software/cuda-12.9.1/bin:/usr/bin:/home/jzzeng/miniconda3/bin:$PATH"
export LD_LIBRARY_PATH="$deps/lib:/group/software/cuda-12.9.1/lib64:${LD_LIBRARY_PATH:-}"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
ccache --show-stats > "$root/build-admission-cache-before.txt"
trap 'ccache --show-stats > "$root/build-admission-cache-after.txt"' EXIT
mkdir -p "$root/baseline-source"
tar -xzf "$root/admission-parent.tar.gz" -C "$root/baseline-source"
for variant in candidate base; do
  source="$root/production-source"
  if [[ "$variant" == base ]]; then source="$root/baseline-source"; fi
  output="$root/$variant-admission"
  mkdir -p "$output"
  export CCACHE_BASEDIR="$source"
  cd "$source"
  printf '%s\n' configuring > "$output/status.txt"
  cmake -S . -B build-cuda -GNinja -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_CXX_COMPILER=/usr/bin/g++ -DCMAKE_C_COMPILER=/usr/bin/gcc \
    -DCMAKE_CUDA_HOST_COMPILER=/usr/bin/g++ \
    -DPython3_EXECUTABLE=/home/jzzeng/miniconda3/bin/python \
    -DGENERATIVEQC_ENABLE_CUDA=ON -DCMAKE_CUDA_ARCHITECTURES=120 \
    -DGENERATIVEQC_BUILD_TESTS=OFF -DGENERATIVEQC_BUILD_CLI=OFF \
    -DGENERATIVEQC_ENABLE_AOT_SHELLS=ON -DGENERATIVEQC_AOT_PROFILE=portable_cuda \
    -DGENERATIVEQC_BUNDLE_XTB_OPENBLAS=OFF \
    -DCMAKE_CXX_COMPILER_LAUNCHER=ccache -DCMAKE_CUDA_COMPILER_LAUNCHER=ccache \
    > "$output/configure.log" 2>&1
  printf '%s\n' building > "$output/status.txt"
  cmake --build build-cuda --target generativeqc -j8 > "$output/build.log" 2>&1
  cp build-cuda/libgenerativeqc.so "$output/"
  ln -sfn libgenerativeqc.so "$output/libgenerativeqc.so.0"
  cp -a build-cuda/generated "$output/"
  ccache /usr/bin/g++ -std=c++20 -O2 -DGENERATIVEQC_HAS_CUDA=1 \
    -Iinclude -Isrc -I/group/software/cuda-12.9.1/include \
    -c benchmarks/df_ccsdt_force_endpoint.cpp -o "$output/endpoint.o"
  /usr/bin/g++ "$output/endpoint.o" "$output/libgenerativeqc.so" \
    -Wl,-rpath,"$output" -o "$output/endpoint"
  sha256sum "$output/libgenerativeqc.so" "$output/endpoint" > "$output/binaries.sha256"
  printf '%s\n' complete > "$output/status.txt"
done
