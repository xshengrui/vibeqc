"""Fresh matched complete molecular endpoints; no standalone speedup promotion."""

from __future__ import annotations

import hashlib
import json
import math
import os
import statistics
import subprocess
import time
from math import prod
from pathlib import Path

from tools import generate_df_ccsd_hoisted as original
from tools import generate_df_ccsd_spectator_pairs as paired

ROOT = Path("/data/jzzeng/qc-cc-spectator-pairs-20261010")
SOURCE = ROOT / "production-source"
DEPS = Path("/data/jzzeng/issue1972-20261005/deps")
OUT = ROOT / "admission-results"
OUT.mkdir(exist_ok=True)
input_path = SOURCE / "benchmarks/results/rccsd-diis-ring-1900/ethane230.input"
oracle_path = (
    SOURCE / "benchmarks/results/df-lambda-cost-2136-20261009/oracle-energy.json"
)
oracle = json.loads(oracle_path.read_text())


def checksum(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def summands(program) -> int:
    dimensions = {
        "occupied": oracle["nocc"],
        "virtual": oracle["nvir"],
        "pair": oracle["nocc"] * (oracle["nocc"] + 1) // 2,
        "batch": 1,
    }
    return sum(
        prod(
            {
                label: dimensions[index.space.kind]
                for child, labels in zip(node.inputs, node.attrs["labels"], strict=True)
                for label, index in zip(labels, child.spec.indices, strict=True)
            }.values()
        )
        for node in program.live_nodes
        if node.op == "einsum"
    )


saved_per_q = summands(original.packed_programs()["auxiliary"]) - summands(
    paired.programs()["auxiliary_packed"]
)
assert saved_per_q > 0
device = json.loads(subprocess.check_output([str(ROOT / "visible-device")], text=True))
provenance = {
    "parent": (ROOT / "admission-parent.txt").read_text().strip(),
    "slurm_job": os.environ["SLURM_JOB_ID"],
    "visibility": os.environ["CUDA_VISIBLE_DEVICES"],
    "device": device,
    "input_sha256": checksum(input_path),
    "oracle_sha256": checksum(oracle_path),
    "overlay_sha256": checksum(ROOT / "admission-overlay-v3.tar.gz"),
    "libraries": {
        variant: checksum(ROOT / (variant + "-admission") / "libgenerativeqc.so")
        for variant in ("base", "candidate")
    },
    "executables": {
        variant: checksum(ROOT / (variant + "-admission") / "endpoint")
        for variant in ("base", "candidate")
    },
    "timing_boundary": "fresh process: native molecular RHF, DF source, CCSD including per-state admission/projection, independent expanded replay, FP64 (T), and owner teardown",
    "forces_requested": False,
    "precision": "FP64, pedantic matrix GEMMs, original ordered Q accumulation",
    "packed_diis": False,
    "saved_auxiliary_summands_per_admitted_primary_q": saved_per_q,
}
(OUT / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
controls = ["1", "1", "0", "1", "8", "8", "8", "0", "0", "2", "1", "30", "0", "0", "0"]
invariants = (
    "ccsd_iterations",
    "ccsd_evaluations",
    "ccsd_q_batch_size",
    "ccsd_q_slices",
    "ccsd_q_tiles",
    "ccsd_accumulation_calls",
    "ccsd_accumulation_bytes",
    "reference_iterations",
    "derived_d2_iteration_evaluations",
    "ccsd_setup_h2d_bytes",
)
observations = []
for sample, variant in enumerate(("base", "candidate", "candidate", "base")):
    output = OUT / f"{sample:02d}-{variant}.json"
    directory = ROOT / (variant + "-admission")
    command = [str(directory / "endpoint"), str(input_path), str(output), *controls]
    environment = dict(os.environ)
    environment["LD_LIBRARY_PATH"] = ":".join(
        (str(directory), str(DEPS / "lib"), "/group/software/cuda-12.9.1/lib64")
    )
    environment.pop("GENERATIVEQC_DF_PROGRESS_TRACE", None)
    print(f"starting {sample} {variant}", flush=True)
    started = time.perf_counter()
    with output.with_suffix(".log").open("w") as stream:
        subprocess.run(
            command,
            env=environment,
            stdout=stream,
            stderr=subprocess.STDOUT,
            check=True,
            timeout=600,
        )
    wall = time.perf_counter() - started
    record = json.loads(output.read_text())
    assert record["nbf"] == oracle["nocc"] + oracle["nvir"]
    assert record["naux"] == oracle["naux"]
    assert (
        record["ccsd_q_slices"] - record["naux"] * record["ccsd_evaluations"]
        == record["naux"]
    )
    assert record["ccsd_replay_matrix_gemm"] == 1
    gates = {
        "total_energy_error": abs(record["total_energy"] - oracle["total_energy"]),
        "triples_energy_error": abs(
            record["triples_energy"] - oracle["triples_energy"]
        ),
        "physical_replay_r1": record["ccsd_replay_r1_max"],
        "physical_replay_r2": record["ccsd_replay_r2_max"],
    }
    gates["passed"] = (
        gates["total_energy_error"] <= 1e-8
        and gates["triples_energy_error"] <= 1e-10
        and max(gates["physical_replay_r1"], gates["physical_replay_r2"]) <= 1e-10
    )
    for key in (
        "native_seconds",
        "reference_seconds",
        "source_seconds",
        "ccsd_seconds",
        "triples_seconds",
    ):
        assert math.isfinite(record[key]) and record[key] >= 0
    observations.append(
        {
            "variant": variant,
            "command": command,
            "process_wall_seconds": wall,
            "record": record,
            "gates": gates,
        }
    )
    (OUT / "samples.json").write_text(json.dumps(observations, indent=2) + "\n")
    assert gates["passed"], gates
    control = observations[0]["record"]
    assert all(record[key] == control[key] for key in invariants), (
        "solver trajectory changed"
    )
    evaluations = record.get("ccsd_pair_evaluations", 0)
    if variant == "candidate":
        assert record["ccsd_occupied_pairs"] and evaluations > 0
        assert (
            evaluations + record["ccsd_pair_refusals"]
            == record["ccsd_pair_projection_calls"]
            == record["ccsd_evaluations"]
        )
    assert (
        control["ccsd_contraction_terms"] - record["ccsd_contraction_terms"]
        == record["naux"] * evaluations * saved_per_q
    )
    assert abs(record["total_energy"] - control["total_energy"]) <= 2e-11
    print(variant, wall, record["ccsd_seconds"], evaluations, flush=True)

keys = (
    "native_seconds",
    "reference_seconds",
    "source_seconds",
    "ccsd_seconds",
    "triples_seconds",
    "ccsd_iteration_seconds",
    "ccsd_replay_seconds",
    "ccsd_diis_seconds",
    "ccsd_update_seconds",
    "ccsd_packing_bytes",
    "ccsd_capacity",
    "ccsd_q_operations",
    "ccsd_gemm_calls",
    "ccsd_gemm_summands",
    "ccsd_contraction_terms",
)
medians = {
    variant: {
        key: statistics.median(
            item["record"][key] for item in observations if item["variant"] == variant
        )
        for key in keys
    }
    for variant in ("base", "candidate")
}
for variant, values in medians.items():
    values["complete_process_wall_seconds"] = statistics.median(
        item["process_wall_seconds"]
        for item in observations
        if item["variant"] == variant
    )
summary = {
    "provenance": provenance,
    "medians": medians,
    "complete_process_wall_speedup": medians["base"]["complete_process_wall_seconds"]
    / medians["candidate"]["complete_process_wall_seconds"],
    "ccsd_speedup": medians["base"]["ccsd_seconds"]
    / medians["candidate"]["ccsd_seconds"],
    "all_scientific_gates_passed": True,
    "all_contraction_deltas_exact": True,
    "interpretation": "two fresh samples per selection in ABBA order, scoped numerical qualification and observed endpoint timing, not formal/global performance or force promotion",
}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2), flush=True)
