#!/usr/bin/env bash
set -euo pipefail
root=/data/jzzeng/qc-cc-spectator-pairs-20261010
deps=/data/jzzeng/issue1972-20261005/deps
export PATH="$deps/bin:/group/software/cuda-12.9.1/bin:/usr/bin:/home/jzzeng/miniconda3/bin:$PATH"
export LD_LIBRARY_PATH="$deps/lib:/group/software/cuda-12.9.1/lib64:${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$root/production-source/python:$root/production-source:$deps"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export GENERATIVEQC_DF_CC_CUDA_TEST=1 GENERATIVEQC_DF_CC_SAVE_INPUTS=1
export CCACHE_BASEDIR="$root/production-source"
cd "$root/production-source"
printf '%s\n' "$SLURM_JOB_ID" "$CUDA_VISIBLE_DEVICES" > "$root/admission-gpu-allocation.txt"
ccache --show-stats > "$root/admission-cache-before.txt"
trap 'ccache --show-stats > "$root/admission-cache-after.txt"' EXIT
/home/jzzeng/miniconda3/bin/python -m pytest -q tests/python/test_df_cc_pair_projection.py \
  --basetemp "$root/pytest-projection" > "$root/admission-projection-tests.log" 2>&1
/home/jzzeng/miniconda3/bin/python -m pytest -q tests/python/test_df_cc_native_solver.py -k cuda \
  --basetemp "$root/pytest-owner" > "$root/admission-owner-tests.log" 2>&1
probe="$root/pytest-projection/df-pair-projection0/probe"
compute-sanitizer --tool memcheck --error-exitcode=86 "$probe" \
  < "$(dirname "$probe")/case-3-2.txt" > "$root/admission-projection-memcheck.log" 2>&1
