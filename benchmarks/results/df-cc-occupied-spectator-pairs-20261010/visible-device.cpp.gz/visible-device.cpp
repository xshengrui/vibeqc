#include <cuda_runtime.h>

#include <cstdio>

int main() {
  cudaDeviceProp properties{};
  int ordinal{}, driver{}, runtime{};
  if (cudaGetDevice(&ordinal) || cudaGetDeviceProperties(&properties, ordinal) ||
      cudaDriverGetVersion(&driver) || cudaRuntimeGetVersion(&runtime))
    return 1;
  std::printf("{\"name\":\"%s\",\"uuid\":\"GPU-", properties.name);
  for (int index = 0; index < 16; ++index) {
    if (index == 4 || index == 6 || index == 8 || index == 10) std::putchar('-');
    std::printf("%02x", static_cast<unsigned char>(properties.uuid.bytes[index]));
  }
  std::printf("\",\"cuda_driver_api\":%d,\"cuda_runtime\":%d}\n", driver, runtime);
}
