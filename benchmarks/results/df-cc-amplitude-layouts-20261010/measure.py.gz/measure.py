"""Matched fresh-process complete endpoints; oracle checks remain outside timing."""

import hashlib
import json
import math
import os
import statistics
import subprocess
import time
from pathlib import Path

ROOT = Path('/data/jzzeng/qc-cc-layout-20261010')
SOURCE = ROOT / 'source'
DEPS = Path('/data/jzzeng/issue1972-20261005/deps')
OUT = ROOT / 'measurements'
OUT.mkdir(exist_ok=True)


def checksum(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


input_path = SOURCE / 'benchmarks/results/rccsd-diis-ring-1900/ethane230.input'
oracle_path = SOURCE / 'benchmarks/results/df-lambda-cost-2136-20261009/oracle-energy.json'
oracle = json.loads(oracle_path.read_text())
provenance = {
    'base_commit': 'ec71ef7fea6f705a3623b45c7bfb51105c43337a',
    'slurm_job': os.environ['SLURM_JOB_ID'],
    'visibility': os.environ['CUDA_VISIBLE_DEVICES'],
    'device': subprocess.check_output(['nvidia-smi', '--id=' + os.environ['CUDA_VISIBLE_DEVICES'], '--query-gpu=uuid,name,driver_version,power.limit', '--format=csv,noheader'], text=True).strip(),
    'input_sha256': checksum(input_path),
    'oracle_sha256': checksum(oracle_path),
    'measured_patch_sha256': checksum(ROOT / 'candidate.patch'),
    'libraries': {variant: checksum(ROOT / variant / 'libgenerativeqc.so') for variant in ('base', 'candidate')},
    'executables': {variant: checksum(ROOT / variant / 'endpoint') for variant in ('base', 'candidate')},
    'timing_boundary': 'native helper: molecular RHF, DF source, CCSD, independent expanded replay and FP64 (T), including inner phase-owner teardown; fresh-process wall additionally includes startup and all final caller/reference cleanup',
    'forces_requested': False,
}
(OUT / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
controls = ['1', '1', '0', '1', '8', '8', '8', '0', '0', '2', '1', '30', '0', '0', '1']
observations = []
work = ['ccsd_iterations', 'ccsd_evaluations', 'ccsd_q_batch_size', 'ccsd_q_slices', 'ccsd_q_tiles', 'ccsd_gemm_calls', 'ccsd_gemm_summands', 'ccsd_contraction_terms', 'ccsd_accumulation_calls', 'ccsd_accumulation_bytes']
for index, variant in enumerate(('base', 'candidate', 'candidate', 'base')):
    output = OUT / f'{index:02d}-{variant}.json'
    command = [str(ROOT / variant / 'endpoint'), str(input_path), str(output), *controls]
    env = dict(os.environ)
    env['LD_LIBRARY_PATH'] = ':'.join((str(ROOT / variant), str(DEPS / 'lib'), '/group/software/cuda-12.9.1/lib64'))
    env.pop('GENERATIVEQC_DF_PROGRESS_TRACE', None)
    print(f'starting {index} {variant}', flush=True)
    started = time.perf_counter()
    with output.with_suffix('.log').open('w') as log:
        subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=900, check=True)
    wall = time.perf_counter() - started
    record = json.loads(output.read_text())
    energy_error = abs(record['total_energy'] - oracle['total_energy'])
    triples_error = abs(record['triples_energy'] - oracle['triples_energy'])
    gates = {
        'total_energy_error': energy_error,
        'triples_energy_error': triples_error,
        'physical_replay_r1': record['ccsd_replay_r1_max'],
        'physical_replay_r2': record['ccsd_replay_r2_max'],
        'passed': energy_error <= 1e-8 and triples_error <= 1e-10 and max(record['ccsd_replay_r1_max'], record['ccsd_replay_r2_max']) <= 1e-10,
    }
    assert all(math.isfinite(record[key]) and record[key] >= 0 for key in ('native_seconds', 'reference_seconds', 'source_seconds', 'ccsd_seconds', 'triples_seconds'))
    assert gates['passed'], gates
    if observations:
        assert all(record[key] == observations[0]['record'][key] for key in work), 'semantic work/solver trajectory changed'
        assert abs(record['total_energy'] - observations[0]['record']['total_energy']) <= 2e-11
    observations.append({'variant': variant, 'command': command, 'process_wall_seconds': wall, 'record': record, 'gates': gates})
    (OUT / 'samples.json').write_text(json.dumps(observations, indent=2) + '\n')
    print(variant, record['native_seconds'], record['ccsd_seconds'], record['ccsd_packing_bytes'], flush=True)
medians = {variant: {key: statistics.median(item['record'][key] for item in observations if item['variant'] == variant) for key in ('native_seconds', 'reference_seconds', 'source_seconds', 'ccsd_seconds', 'triples_seconds', 'ccsd_packing_bytes', 'ccsd_capacity', 'ccsd_q_operations')} for variant in ('base', 'candidate')}
for variant in medians:
    medians[variant]['complete_process_wall_seconds'] = statistics.median(item['process_wall_seconds'] for item in observations if item['variant'] == variant)
summary = {
    'provenance': provenance,
    'medians': medians,
    'native_speedup': medians['base']['native_seconds'] / medians['candidate']['native_seconds'],
    'complete_process_wall_speedup': medians['base']['complete_process_wall_seconds'] / medians['candidate']['complete_process_wall_seconds'],
    'ccsd_speedup': medians['base']['ccsd_seconds'] / medians['candidate']['ccsd_seconds'],
    'all_scientific_gates_passed': True,
    'all_semantic_work_matched': True,
    'interpretation': 'four observations; no broad public performance claim; phase times are disjoint and not attributed across modified/unmodified phases',
}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2), flush=True)
