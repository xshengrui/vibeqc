"""Retained Q-invariant layouts must be refreshed for each amplitude state."""

from __future__ import annotations

from unittest.mock import patch

import numpy as np
import pytest
from generativeqc_compiler.cc.df_gemm import pack_df_contractions
from generativeqc_compiler.cc.df_hoist import (
    build_df_auxiliary_reduction_programs,
    prepare_df_auxiliary_layouts,
)
from generativeqc_compiler.cc.df_lambda_matrix import matrix_program
from generativeqc_compiler.tensor import Node, Program, execute
from generativeqc_compiler.tensor.iteration_reuse import analyze_iteration_reuse

from tools import generate_df_ccsd_hoisted as generator


@pytest.mark.parametrize("nocc,nvir,batch", [(1, 3, 2), (2, 3, 3), (3, 2, 4)])
def test_layout_cuts_preserve_both_consumers_and_refresh_amplitudes(
    nocc: int, nvir: int, batch: int
) -> None:
    pipeline = build_df_auxiliary_reduction_programs(nocc, nvir)
    original_prepare = pack_df_contractions(pipeline.prepare)
    original_auxiliary = pack_df_contractions(pipeline.auxiliary)
    original_batched = matrix_program(pipeline.auxiliary, batch_size=batch)
    layouts = prepare_df_auxiliary_layouts(
        original_prepare, original_auxiliary, original_batched
    )
    rng = np.random.default_rng(20261010 + nocc)
    bvv = rng.normal(size=(batch, nvir, nvir))
    factors = {
        "bov": rng.normal(size=(batch, nocc, nvir)),
        "bvv": (bvv + bvv.transpose(0, 2, 1)) / 2,
    }
    for state in range(2):
        doubles = rng.normal(scale=0.2 + state, size=(nocc, nocc, nvir, nvir))
        feeds = {
            **factors,
            "t1": rng.normal(scale=0.1 + state, size=(nocc, nvir)),
            "t2": (doubles + doubles.transpose(1, 0, 3, 2)) / 2,
        }
        original = execute(original_prepare, feeds).outputs
        prepared = execute(layouts.prepare, feeds).outputs
        np.testing.assert_array_equal(prepared["df_tau"], original["df_tau"])
        for reference, candidate, row in (
            (
                original_auxiliary,
                layouts.auxiliary,
                {key: value[0] for key, value in factors.items()},
            ),
            (original_batched, layouts.batched_auxiliary, factors),
        ):
            expected = execute(reference, {**feeds, **original, **row}).outputs
            actual = execute(candidate, {**feeds, **prepared, **row}).outputs
            for name in expected:
                np.testing.assert_allclose(
                    actual[name], expected[name], atol=2e-12, rtol=0
                )


def _independent_operations(program: Program) -> tuple[Node, ...]:
    """Use the same backend-neutral proof, not names or shapes of layouts."""
    return analyze_iteration_reuse(
        program,
        invariant_inputs=tuple(
            node.attrs["name"]
            for node in program.live_nodes
            if node.op == "input" and node.attrs["name"] not in ("bov", "bvv")
        ),
    ).invariant_nodes


def test_generated_layout_work_occurs_once_and_is_owner_admitted() -> None:
    layouts = generator.layout_programs()
    assert len(layouts.fields) == 4
    assert len(layouts.prepare.outputs) == 5
    assert not _independent_operations(layouts.auxiliary)
    assert not _independent_operations(layouts.batched_auxiliary)
    assert {
        node.attrs["name"] for node in layouts.prepare.live_nodes if node.op == "input"
    } == {"t1", "t2"}
    assert all(
        sum(index.space.kind == "virtual" for index in node.spec.indices) <= 2
        for program in (layouts.prepare, layouts.auxiliary, layouts.batched_auxiliary)
        for node in program.live_nodes
    )
    with patch.object(
        generator, "_cuda_program", wraps=generator._cuda_program
    ) as emitter:
        source = generator.cuda_source()
    prepared_fields = [
        call.kwargs["output_fields"]
        for call in emitter.call_args_list
        if call.args[1] == "prepare_packed"
    ]
    assert prepared_fields == [("df_tau", *layouts.fields)]
    for field in layouts.fields:
        assert f"s.{field}=prepared.{field};" in source
    assert "if(!s.prepare_contractions) return run_prepare_scalar(s);" in source
    assert "prepare_packed_arena_elements" in generator.cpu_header()
    assert (
        layouts.prepare.logical_hash
        == generator.packed_programs()["prepare"].logical_hash
    )
