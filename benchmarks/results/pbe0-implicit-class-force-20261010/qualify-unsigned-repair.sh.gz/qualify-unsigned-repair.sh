#!/usr/bin/env bash
set -euo pipefail
export NEXT_VARIANT=candidate-force7-class-unsigned-v1
unset VARIANT
source /data/jzzeng/qc-next-hotspot-20261009-125a4e33f/env-next.sh
: "${SLURM_JOB_ID:?}" "${CUDA_VISIBLE_DEVICES:?}"
export EVIDENCE="$ROOT/evidence/force7-class-unsigned-v2"
mkdir -p "$EVIDENCE"
test ! -f "$EVIDENCE/job.txt"
printf 'job=%s visibility=%s\n' "$SLURM_JOB_ID" "$CUDA_VISIBLE_DEVICES" > "$EVIDENCE/job.txt"
"$GENERATIVEQC_CCACHE" --version > "$EVIDENCE/cache-version.txt"
"$GENERATIVEQC_CCACHE" --show-stats > "$EVIDENCE/cache-before.txt"
cmake -S . -B build/cuda-release-sm120 -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DGENERATIVEQC_ENABLE_CUDA=ON \
  -DGENERATIVEQC_CUDA_ARCHITECTURES=120 \
  -DCMAKE_CUDA_COMPILER="$CUDA_PATH/bin/nvcc" \
  -DCMAKE_CXX_COMPILER=/usr/bin/c++ \
  -DCMAKE_CXX_COMPILER_LAUNCHER="$GENERATIVEQC_CCACHE" \
  -DCMAKE_CUDA_COMPILER_LAUNCHER="$GENERATIVEQC_CCACHE" \
  -DPython_EXECUTABLE="$PYTHON" -DPython3_EXECUTABLE="$PYTHON" \
  -DGENERATIVEQC_CUDA_COMPILE_JOBS=8 -DGENERATIVEQC_AOT_COMPILE_JOBS=2 \
  -DGENERATIVEQC_AOT_SPLIT_COMPILE_THREADS=8 \
  > "$EVIDENCE/configure.log" 2>&1
ninja -C build/cuda-release-sm120 -t commands > "$EVIDENCE/compiler-commands.txt"
awk 'index($0, "direct_order_seven_force.cu.o") && !printed {print; printed=1}' \
  "$EVIDENCE/compiler-commands.txt" > "$EVIDENCE/class-command.txt"
grep -F "$GENERATIVEQC_CCACHE" "$EVIDENCE/class-command.txt" >/dev/null
cmake --build build/cuda-release-sm120 --parallel 16 --target generativeqc \
  > "$EVIDENCE/build.log" 2>&1
sha256sum src/scf/cuda/direct_order_seven_force.cu "$GENERATIVEQC_LIBRARY" \
  > "$EVIDENCE/identities.sha256"
"$GENERATIVEQC_CCACHE" --show-stats > "$EVIDENCE/cache-after-build.txt"
date -Iseconds > "$EVIDENCE/build-completed.txt"
export GENERATIVEQC_RESOURCE_CUDA_TEST=1
export GENERATIVEQC_ONE_ELECTRON_DERIVATIVE_MAPPING=nucleus_cooperative
export GENERATIVEQC_DIRECT_PAIR_MATERIALIZED_DERIVATIVES=1
export GENERATIVEQC_DIRECT_PAIR_COOPERATIVE_DERIVATIVES=1
export GENERATIVEQC_BOUNDED_ANGULAR_FORCE=off
observer="$ROOT/evidence/force7-class-master-v1/sanitizer/force-launch-observer.so"
test -f "$observer"
sha256sum "$observer" > "$EVIDENCE/observer.sha256"
export QC_FORCE_LAUNCH_LOG="$EVIDENCE/launches.jsonl"
LD_PRELOAD="$observer:$LD_PRELOAD" "$PYTHON" -m pytest -q \
  tests/python/test_cuda_hybrid_snapshot.py::test_separate_full_range_derivatives_match_libcint \
  -k bounded-True-1-cartesian-pbe0-rks --basetemp "$EVIDENCE/test-tmp" \
  --junitxml "$EVIDENCE/libcint.xml" > "$EVIDENCE/libcint.log" 2>&1
"$PYTHON" - "$EVIDENCE/libcint.xml" "$QC_FORCE_LAUNCH_LOG" <<'PY'
import json
import sys
import xml.etree.ElementTree as tree

cases = tree.parse(sys.argv[1]).getroot().findall(".//testcase")
assert len(cases) == 1 and not any(case.find(kind) is not None for case in cases for kind in ("skipped", "failure", "error"))
counts = [json.loads(line) for line in open(sys.argv[2])]
assert sum(item["class_launches"] for item in counts) >= 3, counts
print("Independent Separate/Combined/replay libcint case executed; actual class launches verified.")
PY
"$GENERATIVEQC_CCACHE" --show-stats > "$EVIDENCE/cache-after-gate.txt"
date -Iseconds > "$EVIDENCE/completed.txt"
