#!/usr/bin/env bash
set -euo pipefail
export NEXT_VARIANT=candidate-force7-class-master-v1
unset VARIANT
source /data/jzzeng/qc-next-hotspot-20261009-125a4e33f/env-next.sh
: "${SLURM_JOB_ID:?}" "${CUDA_VISIBLE_DEVICES:?}"
export EVIDENCE="$ROOT/evidence/force7-class-master-v1/package-integration"
mkdir -p "$EVIDENCE"
test ! -f "$EVIDENCE/job.txt"
printf 'job=%s visibility=%s\n' "$SLURM_JOB_ID" "$CUDA_VISIBLE_DEVICES" > "$EVIDENCE/job.txt"
"$GENERATIVEQC_CCACHE" --version > "$EVIDENCE/cache-version.txt"
"$GENERATIVEQC_CCACHE" --show-stats > "$EVIDENCE/cache-before.txt"
cmake --build build/cuda-release-sm120 --parallel 16 --target \
  generativeqc_stationary_pbe0_rks_manifest generativeqc_stationary_pbe0_uks_manifest \
  generativeqc_stationary_pbe0_rks_spd_manifest generativeqc_stationary_pbe0_uks_spd_manifest \
  > "$EVIDENCE/build.log" 2>&1
ninja -C build/cuda-release-sm120 -t commands > "$EVIDENCE/compiler-commands.txt"
grep -F "$GENERATIVEQC_CCACHE" "$EVIDENCE/compiler-commands.txt" >/dev/null
sha256sum build/cuda-release-sm120/*stationary*pbe0*.json \
  build/cuda-release-sm120/libgenerativeqc_stationary_pbe0*.so \
  "$GENERATIVEQC_LIBRARY" > "$EVIDENCE/identities.sha256"
"$GENERATIVEQC_CCACHE" --show-stats > "$EVIDENCE/cache-after-build.txt"
date -Iseconds > "$EVIDENCE/build-completed.txt"
export GENERATIVEQC_RESOURCE_CUDA_TEST=1
export GENERATIVEQC_ONE_ELECTRON_DERIVATIVE_MAPPING=nucleus_cooperative
export GENERATIVEQC_DIRECT_PAIR_COOPERATIVE_DERIVATIVES=1
"$PYTHON" -m pytest -q \
  tests/python/test_cuda_hybrid_snapshot.py::test_cuda_hybrid_snapshot_matches_cpu_composition_and_state \
  -k pbe0 --basetemp "$EVIDENCE/rechecked-snapshots-tmp" \
  --junitxml "$EVIDENCE/rechecked-snapshots.xml" > "$EVIDENCE/rechecked-snapshots.log" 2>&1
"$PYTHON" - "$ROOT/evidence/force7-class-master-v1/final/current-integration.xml" \
  "$EVIDENCE/rechecked-snapshots.xml" <<'PY'
import sys
import xml.etree.ElementTree as tree

original = tree.parse(sys.argv[1]).getroot().findall(".//testcase")
rechecked = tree.parse(sys.argv[2]).getroot().findall(".//testcase")
assert len(original) == 16 and len(rechecked) == 2
failed = {(case.get("classname"), case.get("name")) for case in original if case.find("failure") is not None}
assert len(failed) == 2
assert failed == {(case.get("classname"), case.get("name")) for case in rechecked}
assert not any(case.find(kind) is not None for case in rechecked for kind in ("skipped", "failure", "error"))
passed = [case for case in original if case.find("failure") is None]
assert len(passed) == 14 and not any(case.find(kind) is not None for case in passed for kind in ("skipped", "error"))
print("14 original energy-delta passes retained; precisely the two missing-package failures rechecked and passed.")
PY
"$GENERATIVEQC_CCACHE" --show-stats > "$EVIDENCE/cache-after-gate.txt"
date -Iseconds > "$ROOT/evidence/force7-class-master-v1/final/current-integration-completed.txt"
