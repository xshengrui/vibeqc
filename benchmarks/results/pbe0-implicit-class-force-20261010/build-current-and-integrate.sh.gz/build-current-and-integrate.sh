#!/usr/bin/env bash
set -euo pipefail
export NEXT_VARIANT=candidate-force7-class-master-v1
unset VARIANT
source /data/jzzeng/qc-next-hotspot-20261009-125a4e33f/env-next.sh
: "${SLURM_JOB_ID:?}" "${CUDA_VISIBLE_DEVICES:?}"
export EVIDENCE="$ROOT/evidence/force7-class-master-v1/final"
mkdir -p "$EVIDENCE"
test ! -f "$EVIDENCE/build-job.txt"
printf 'job=%s visibility=%s\n' "$SLURM_JOB_ID" "$CUDA_VISIBLE_DEVICES" > "$EVIDENCE/build-job.txt"
"$GENERATIVEQC_CCACHE" --version > "$EVIDENCE/cache-version.txt"
"$GENERATIVEQC_CCACHE" --show-stats > "$EVIDENCE/cache-before.txt"
cmake -S . -B build/cuda-release-sm120 -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DGENERATIVEQC_ENABLE_CUDA=ON \
  -DGENERATIVEQC_CUDA_ARCHITECTURES=120 \
  -DCMAKE_CUDA_COMPILER="$CUDA_PATH/bin/nvcc" \
  -DCMAKE_CXX_COMPILER=/usr/bin/c++ \
  -DCMAKE_CXX_COMPILER_LAUNCHER="$GENERATIVEQC_CCACHE" \
  -DCMAKE_CUDA_COMPILER_LAUNCHER="$GENERATIVEQC_CCACHE" \
  -DPython_EXECUTABLE="$PYTHON" -DPython3_EXECUTABLE="$PYTHON" \
  -DGENERATIVEQC_CUDA_COMPILE_JOBS=8 -DGENERATIVEQC_AOT_COMPILE_JOBS=2 \
  -DGENERATIVEQC_AOT_SPLIT_COMPILE_THREADS=8 > "$EVIDENCE/configure.log" 2>&1
ninja -C build/cuda-release-sm120 -t commands > "$EVIDENCE/compiler-commands.txt"
for owner in direct_order_seven_force.cu direct_bounded_fallback.cu direct_jk_kernels.cu direct_coulomb.cpp; do
  awk -v owner="$owner.o" 'index($0, owner) && !printed {print; printed=1}' \
    "$EVIDENCE/compiler-commands.txt" > "$EVIDENCE/$owner.command.txt"
  grep -F "$GENERATIVEQC_CCACHE" "$EVIDENCE/$owner.command.txt" >/dev/null
done
cmake --build build/cuda-release-sm120 --parallel 16 --target generativeqc \
  > "$EVIDENCE/build.log" 2>&1
sha256sum src/scf/cuda/direct_order_seven_force.cu src/scf/cuda/direct_order_seven_pages.cuh \
  src/scf/cuda/direct_bounded_fallback.cu src/scf/cuda/direct_coulomb.cpp \
  src/scf/cuda/direct_jk_kernels.cu "$GENERATIVEQC_LIBRARY" > "$EVIDENCE/identities.sha256"
"$GENERATIVEQC_CCACHE" --show-stats > "$EVIDENCE/cache-after-build.txt"
date -Iseconds > "$EVIDENCE/build-completed.txt"
export GENERATIVEQC_RESOURCE_CUDA_TEST=1
export GENERATIVEQC_ONE_ELECTRON_DERIVATIVE_MAPPING=nucleus_cooperative
export GENERATIVEQC_DIRECT_PAIR_COOPERATIVE_DERIVATIVES=1
"$PYTHON" -m pytest -q \
  tests/python/test_cuda_hybrid_snapshot.py::test_cuda_hybrid_snapshot_matches_cpu_composition_and_state \
  tests/python/test_cuda_ks_energy_change.py \
  -k 'not b3lyp' --basetemp "$EVIDENCE/current-integration-tmp" \
  --junitxml "$EVIDENCE/current-integration.xml" > "$EVIDENCE/current-integration.log" 2>&1
"$PYTHON" - "$EVIDENCE/current-integration.xml" <<'PY'
import sys
import xml.etree.ElementTree as tree

cases = tree.parse(sys.argv[1]).getroot().findall(".//testcase")
assert len(cases) == 16, len(cases)
assert not any(case.find(kind) is not None for case in cases for kind in ("skipped", "failure", "error"))
print("Focused current-master K/snapshot and CPU/CUDA decimal energy-delta integration: 16 executed passes, no skips.")
PY
"$GENERATIVEQC_CCACHE" --show-stats > "$EVIDENCE/cache-after-gate.txt"
date -Iseconds > "$EVIDENCE/current-integration-completed.txt"
