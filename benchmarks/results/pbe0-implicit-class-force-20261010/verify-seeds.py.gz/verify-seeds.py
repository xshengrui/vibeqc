"""Verify frozen public native density/coordinate bytes for each captured owner."""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np


def canonical_hash(value):
    return hashlib.sha256(json.dumps(
        value, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode()).hexdigest()


def verify_seeds(path, record):
    assert len(record["checkpoints"]) == 8
    checkpoints, labels = {}, set()
    for item in record["checkpoints"]:
        selection, phase, label = item["selection"], item["phase"], item["label"]
        assert selection in ("baseline", "candidate") and phase in ("warm", "moved-warm")
        assert label in ("before", "after") and (selection, phase, label) not in labels
        labels.add((selection, phase, label))
        checkpoint = path.parent / Path(item["path"]).name
        assert hashlib.sha256(checkpoint.read_bytes()).hexdigest() == item["file_sha256"]
        with np.load(checkpoint, allow_pickle=False) as arrays:
            assert arrays["density"].size == record["protocol"]["aos"] ** 2
            assert arrays["coordinates"].size == record["protocol"]["atoms"] * 3
            blobs = {name + "_0": hashlib.sha256(arrays[name].tobytes()).hexdigest()
                     for name in ("density", "coordinates")}
        assert blobs == item["blob_sha256"]
        key = (selection, phase)
        if key in checkpoints:
            assert checkpoints[key] == blobs
        checkpoints[key] = blobs
    for row in record["samples"]:
        phase, selection = row["workload"], row["selection"]
        frozen = checkpoints[selection, phase]
        assert row["frozen_seed_blob_sha256"] == frozen
        inputs = {"protocol": record["protocol"], "geometry": row["geometry"],
                  "native_seed_blobs": frozen}
        assert row["owner_inputs_hash"] == canonical_hash(inputs)
    return {phase: checkpoints["baseline", phase] == checkpoints["candidate", phase]
            for phase in ("warm", "moved-warm")}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("record", type=Path)
    args = parser.parse_args()
    record = json.loads(args.record.read_text())
    print(json.dumps({"status": "pass", "cross_owner_identical_blobs": verify_seeds(args.record, record)}))
