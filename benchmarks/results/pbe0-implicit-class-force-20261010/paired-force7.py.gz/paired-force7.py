"""Same-binary captured-owner controls for the composed force/Hcore candidate."""

import argparse
import ctypes
import hashlib
import importlib.util
import json
import os
import traceback
from pathlib import Path

import numpy as np
from generativeqc import _native
from generativeqc_compiler.common.evidence import canonical_hash
from generativeqc_compiler.common.performance import assess_comparison
from generativeqc_compiler.common.timing import interleaved_selection_order


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main(args):
    assert os.environ.get("SLURM_JOB_ID") and os.environ.get("CUDA_VISIBLE_DEVICES")
    specification = importlib.util.spec_from_file_location(
        "retained_endpoint", args.root / "evidence/bulk-point-v7/paired-ao-endpoint.py"
    )
    retained = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(retained)
    selections = {
        "baseline": {"hcore": "shell_warp", "cooperative_force": "0"},
        "candidate": {"hcore": "nucleus_cooperative", "cooperative_force": "1"},
    }
    owners, shared = {}, {}
    record = {
        "status": "running",
        "scope": "same-native-binary two-owner composed force/Hcore ablation",
        "density_identity_scope": "independently converged seeds; each owner frozen and byte-checked",
        "job": os.environ["SLURM_JOB_ID"],
        "visibility": os.environ["CUDA_VISIBLE_DEVICES"],
        "driver_sha256": digest(Path(__file__)),
        "reference_sha256": digest(args.reference),
        "repeats": args.repeats,
        "selectors": selections,
        "arms": {}, "setup": [], "priming": [], "samples": [],
        "diagnostic_rows": [], "checkpoints": [], "assessments": {},
    }

    def save(stage):
        record["stage"] = stage
        args.output.write_text(json.dumps(record, indent=2) + "\n")

    def select(side):
        os.environ["GENERATIVEQC_ONE_ELECTRON_DERIVATIVE_MAPPING"] = selections[side]["hcore"]
        os.environ["GENERATIVEQC_DIRECT_PAIR_COOPERATIVE_DERIVATIVES"] = selections[side]["cooperative_force"]

    def request(side, **command):
        select(side)
        return owners[side][0](command)

    def checkpoint(side, phase, label):
        handle = owners[side][0]
        closure = dict(zip(handle.__code__.co_freevars, handle.__closure__, strict=True))
        owner = closure["owner"].cell_contents
        state = _native.HfWarmState(
            struct_size=ctypes.sizeof(_native.HfWarmState), abi_version=_native.ABI_VERSION
        )
        function = owner._library.generativeqc_batch_get_hf_warm_state
        _native.check(owner._library, function(owner._batch, 0, ctypes.byref(state)))
        assert state.present and state.density_count == record["protocol"]["aos"] ** 2
        assert state.coordinate_count == 3 * args.atoms
        density = np.empty(state.density_count, dtype=np.float64)
        coordinates = np.empty(state.coordinate_count, dtype=np.float64)
        state.density = density.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
        state.coordinates = coordinates.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
        _native.check(owner._library, function(owner._batch, 0, ctypes.byref(state)))
        assert np.isfinite(density).all() and np.isfinite(coordinates).all()
        path = args.output.with_suffix(f".{phase}-{side}-{label}.npz")
        np.savez(path, density=density, coordinates=coordinates)
        blobs = {
            "density_0": hashlib.sha256(density.tobytes()).hexdigest(),
            "coordinates_0": hashlib.sha256(coordinates.tobytes()).hexdigest(),
        }
        record["checkpoints"].append({
            "selection": side, "phase": phase, "label": label, "path": str(path),
            "file_sha256": digest(path), "blob_sha256": blobs,
        })
        return blobs

    try:
        for side in selections:
            select(side)
            owners[side] = retained.make_owner(args, shared)
            record["arms"][side] = request(side, action="metadata")
            save(f"constructed-{side}")
        record["protocol"] = record["arms"]["baseline"]["protocol"]
        assert record["protocol"] == record["arms"]["candidate"]["protocol"]
        assert record["arms"]["baseline"]["native_build"]["library_sha256"] == record["arms"]["candidate"]["native_build"]["library_sha256"]
        library = Path(os.environ["GENERATIVEQC_LIBRARY"]).resolve()
        maps = Path("/proc/self/maps").read_text()
        assert str(library) in maps
        record["loaded_native_maps"] = [line for line in maps.splitlines() if "libgenerativeqc" in line]
        for geometry, phase in enumerate(("warm", "moved-warm")):
            frozen = {}
            for side in selections:
                row = request(side, action="setup", geometry=geometry)
                record["setup"].append({**row, "selection": side})
                frozen[side] = checkpoint(side, phase, "before")
                save(f"setup-{phase}-{side}")
            inputs = {"protocol": record["protocol"], "geometry": geometry}
            order = tuple(selections) if args.diagnostic else interleaved_selection_order(args.repeats)
            for side in order:
                row = request(side, action="prime")
                record["priming"].append({**row, "selection": side})
                save(f"prime-{phase}-{side}")
                if args.diagnostic:
                    row = request(side, action="diagnostic", profile_prefix=str(
                        args.output.with_suffix(f".{phase}-{side}")
                    ))
                    record["diagnostic_rows"].append({**row, "selection": side, "workload": phase})
                else:
                    row = request(side, action="evaluate")
                    record["samples"].append({
                        **row, "selection": side, "synchronized": True,
                        "inputs_hash": canonical_hash(inputs), "workload": phase,
                        "frozen_seed_blob_sha256": frozen[side],
                        "owner_inputs_hash": canonical_hash({**inputs, "native_seed_blobs": frozen[side]}),
                    })
                print(phase, side, row["seconds"], flush=True)
                save(f"evaluated-{phase}-{side}")
            for side in selections:
                assert checkpoint(side, phase, "after") == frozen[side]
            if not args.diagnostic:
                record["assessments"][phase] = assess_comparison([
                    row for row in record["samples"] if row["workload"] == phase
                ])
            save(f"completed-{phase}")
        record["status"] = "diagnosed" if args.diagnostic else "measured"
        save("complete")
        print(json.dumps(record["assessments"], indent=2), flush=True)
    except BaseException:
        record["status"] = "failed"
        record["error"] = traceback.format_exc()
        save(record.get("stage", "initialization"))
        raise
    finally:
        for handle, close in owners.values():
            close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--atoms", type=int, choices=(48, 96), required=True)
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--basis-file", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument("--diagnostic", action="store_true")
    main(parser.parse_args())
