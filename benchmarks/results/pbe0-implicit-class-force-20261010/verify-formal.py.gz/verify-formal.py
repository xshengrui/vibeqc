"""Independent all-call numerical, work, seed identity and robust timing audit."""

import argparse
import hashlib
import json
import math
from pathlib import Path
from statistics import median

import numpy as np


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical_hash(value):
    return hashlib.sha256(json.dumps(
        value, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode()).hexdigest()


def order(repeats):
    counts = {"baseline": 0, "candidate": 0}
    sequence = []
    while min(counts.values()) < repeats:
        for side in ("baseline", "candidate", "candidate", "baseline"):
            if counts[side] < repeats:
                sequence.append(side)
                counts[side] += 1
    return sequence


def verify(args):
    record = json.loads(args.record.read_text())
    reference = json.loads(args.reference.read_text())
    assert record["status"] == "measured" and record["stage"] == "complete"
    assert reference["engine"] == "reference" and reference["status"] == "measured"
    assert record["reference_sha256"] == digest(args.reference)
    assert record["protocol"] == reference["protocol"]
    assert record["job"] and record["visibility"]
    shared = "same-owner" in record["scope"]
    repeats = record.get("repeats", len(record["samples"]) // 4)
    assert repeats >= 5
    assert len(record["samples"]) == len(record["priming"]) == 4 * repeats
    assert len(record["setup"]) == (2 if shared else 4)
    arms = record["arms"]
    assert set(arms) == {"baseline", "candidate"}
    assert arms["baseline"]["native_build"]["library_sha256"] == arms["candidate"]["native_build"]["library_sha256"]
    for field in ("backend", "device_id", "name", "compute_capability",
                  "total_global_memory_bytes", "multiprocessor_count", "driver_version", "runtime_version"):
        assert arms["baseline"]["accelerator"][field] == arms["candidate"]["accelerator"][field]
    bootstrap = [arms["baseline"]["construction_initialization"]]
    if not shared:
        bootstrap.append(arms["candidate"]["construction_initialization"])
    calls = [(row, True) for row in bootstrap + record["setup"]]
    calls += [(row, False) for row in record["priming"] + record["samples"]]
    energy_errors, force_errors = [], []
    for row, setup in calls:
        actual = row["diagnostics"]
        oracle = next(value for value in reference["records"]
                      if value["geometry"] == row["geometry"] and value["phase"] in ("cold", "moved"))
        observed = np.asarray(actual["forces"], dtype=np.float64)
        expected = np.asarray(oracle["forces"], dtype=np.float64)
        assert observed.shape == expected.shape == (record["protocol"]["atoms"], 3)
        assert np.isfinite(observed).all() and math.isfinite(actual["energy"])
        energy_error = abs(actual["energy"] - oracle["energy"])
        force_error = float(np.max(np.abs(observed - expected)))
        assert energy_error <= 1e-8 and force_error <= 1e-7
        assert actual["status"] == 0 and actual["converged"]
        assert math.isfinite(row["seconds"]) and row["seconds"] > 0
        assert actual["native_ks_diagnostic"]["physical_residual_max"] <= 1e-10
        if not setup:
            assert actual["iterations"] == actual["fock_builds"] == 1
            assert actual["warm_start_used"] and not actual["warm_start_fallback"]
        work = actual["native_force_components"]
        becke = work["becke_owners"]["stationary"]
        assert not becke["profile_enabled"] and not becke["profile_intrusive"]
        assert becke["selection"]["becke_primitive_selected"] == 0
        bounds = work["resource_bounds"]
        assert bounds["additional_device_peak_bound"] <= bounds["additional_device_budget"]
        assert bounds["additional_host_numeric_bound"] <= bounds["additional_host_budget"]
        energy_errors.append(energy_error)
        force_errors.append(force_error)
    checkpoints = {}
    if shared:
        assert len(record["checkpoints"]) == 4
        for item in record["checkpoints"]:
            path = args.record.parent / Path(item["path"]).name
            assert digest(path) == item["file_sha256"]
            with np.load(path, allow_pickle=False) as saved:
                blobs = {name + "_0": hashlib.sha256(saved[name].tobytes()).hexdigest()
                         for name in ("density", "coordinates")}
            assert blobs == item["blob_sha256"]
            if item["phase"] in checkpoints:
                assert checkpoints[item["phase"]] == blobs
            checkpoints[item["phase"]] = blobs
    phases = {}
    assert not shared
    import importlib.util

    specification = importlib.util.spec_from_file_location("seed_verifier", Path(__file__).with_name("verify-seeds.py"))
    seed_verifier = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(seed_verifier)
    seed_scope = seed_verifier.verify_seeds(args.record, record)
    for geometry, phase in enumerate(("warm", "moved-warm")):
        rows = [row for row in record["samples"] if row["workload"] == phase]
        assert [row["selection"] for row in rows] == order(repeats)
        prototype = rows[0]["diagnostics"]
        payload = {"protocol": record["protocol"], "geometry": geometry}
        if shared:
            payload["frozen_seed_blobs"] = checkpoints[phase]
        for row in rows:
            assert row["geometry"] == geometry and row["synchronized"]
            assert row["inputs_hash"] == canonical_hash(payload)
            if shared:
                assert row["frozen_seed_blob_sha256"] == checkpoints[phase]
            current = row["diagnostics"]
            for field in ("grid_work_plan", "resource_bounds", "work_counts", "traffic"):
                assert current["native_force_components"][field] == prototype["native_force_components"][field], (phase, field)
            for field, value in current["native_force_components"]["resident_ao_selection"]["work"].items():
                if not field.endswith("_seconds"):
                    assert value == prototype["native_force_components"]["resident_ao_selection"]["work"][field], (phase, field)
            for field, value in current["native_scf_ao_work"].items():
                if not field.endswith("_seconds"):
                    assert value == prototype["native_scf_ao_work"][field], (phase, field)
        sides = {}
        for side in ("baseline", "candidate"):
            seconds = [row["seconds"] for row in rows if row["selection"] == side]
            assert len(seconds) == repeats
            middle = median(seconds)
            sides[side] = {"raw_seconds": seconds, "median_seconds": middle,
                           "relative_mad": median(abs(value - middle) for value in seconds) / middle}
        gain = 1 - sides["candidate"]["median_seconds"] / sides["baseline"]["median_seconds"]
        noise = max(0.02, 2 * sum(value["relative_mad"] for value in sides.values()))
        phases[phase] = {**sides, "relative_improvement": gain, "noise_floor": noise, "significant": gain > noise,
                         "work_counts": prototype["native_force_components"]["work_counts"]}
    result = {"status": "pass" if all(value["significant"] for value in phases.values()) else "not-qualified",
              "record_sha256": digest(args.record), "reference_sha256": digest(args.reference),
              "complete_calls": len(calls), "cross_owner_identical_blobs": seed_scope,
              "energy_error_max_eh": max(energy_errors),
              "force_error_max_eh_per_bohr": max(force_errors), "phases": phases}
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("record", type=Path)
    parser.add_argument("reference", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    verify(parser.parse_args())
