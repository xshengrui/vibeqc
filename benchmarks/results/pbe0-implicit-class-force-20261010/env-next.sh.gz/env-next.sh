#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/env.sh"
export ROOT=/data/jzzeng/qc-next-hotspot-20261009-125a4e33f
export VARIANT="${NEXT_VARIANT:-candidate}"
export SOURCE="$ROOT/$VARIANT" EVIDENCE="$ROOT/evidence"
export PYTHONPATH="$SOURCE/python:$SOURCE"
export LD_LIBRARY_PATH="$SOURCE/build/cuda-release-sm120:$LD_LIBRARY_PATH"
export GENERATIVEQC_LIBRARY="$SOURCE/build/cuda-release-sm120/libgenerativeqc.so"
export GENERATIVEQC_STATIONARY_CACHE="$ROOT/stationary-cache"
export GENERATIVEQC_BOUNDED_ANGULAR_FORCE=off
export GENERATIVEQC_STATIONARY_BECKE_PRIMITIVE=off
export GENERATIVEQC_BENCHMARK_SOURCE=125a4e33f-ordered-ao-reduction-candidate
export CCACHE_BASEDIR="$SOURCE"
cd "$SOURCE"
