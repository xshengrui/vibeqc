"""Audit intrusive captured-owner numerics, exact class work and launch domains."""

import argparse
import csv
import hashlib
import json
import math
import re
from pathlib import Path

import numpy as np
from importlib.util import module_from_spec, spec_from_file_location


def rows(path):
    with path.open() as source:
        return list(csv.DictReader(source, delimiter="\t"))


def main(args):
    record = json.loads(args.record.read_text())
    reference = json.loads(args.reference.read_text())
    assert record["status"] == "diagnosed" and record["stage"] == "complete"
    assert record["protocol"] == reference["protocol"]
    assert record["reference_sha256"] == hashlib.sha256(args.reference.read_bytes()).hexdigest()
    assert record["arms"]["baseline"]["native_build"]["library_sha256"] == record["arms"]["candidate"]["native_build"]["library_sha256"]
    assert len(record["setup"]) == len(record["priming"]) == len(record["diagnostic_rows"]) == 4
    errors = []
    calls = [record["arms"][side]["construction_initialization"] for side in ("baseline", "candidate")]
    calls += record["setup"] + record["priming"] + record["diagnostic_rows"]
    for row in calls:
        actual = row["diagnostics"]
        oracle = next(item for item in reference["records"]
                      if item["geometry"] == row["geometry"] and item["phase"] in ("cold", "moved"))
        assert actual["status"] == 0 and actual["converged"]
        assert actual["native_ks_diagnostic"]["physical_residual_max"] <= 1e-10
        energy_error = abs(actual["energy"] - oracle["energy"])
        observed, expected = np.asarray(actual["forces"]), np.asarray(oracle["forces"])
        assert observed.shape == expected.shape == (record["protocol"]["atoms"], 3)
        assert np.isfinite(observed).all() and math.isfinite(energy_error)
        force_error = float(np.max(np.abs(observed - expected)))
        assert energy_error <= 1e-8 and force_error <= 1e-7
        bounds = actual["native_force_components"]["resource_bounds"]
        assert bounds["additional_device_peak_bound"] <= bounds["additional_device_budget"]
        assert bounds["additional_host_numeric_bound"] <= bounds["additional_host_budget"]
        errors.append((energy_error, force_error))
    for row in record["priming"] + record["diagnostic_rows"]:
        actual = row["diagnostics"]
        assert actual["iterations"] == actual["fock_builds"] == 1
        assert actual["warm_start_used"] and not actual["warm_start_fallback"]
    specification = spec_from_file_location("seed_verifier", Path(__file__).with_name("verify-seeds.py"))
    module = module_from_spec(specification)
    specification.loader.exec_module(module)
    seed_scope = module.verify_seeds(args.record, record)
    results = {}
    scientific_fields = ("class", "shell_quartets", "ao_quartets", "primitive_ao_quartets", "tiles")
    for phase in ("warm", "moved-warm"):
        arms = {}
        phase_rows = [row for row in record["diagnostic_rows"] if row["workload"] == phase]
        prototype = phase_rows[0]["diagnostics"]
        for row in phase_rows:
            actual = row["diagnostics"]
            for field in ("grid_work_plan", "resource_bounds", "work_counts", "traffic"):
                assert actual["native_force_components"][field] == prototype["native_force_components"][field]
            for field, value in actual["native_scf_ao_work"].items():
                if not field.endswith("_seconds"):
                    assert value == prototype["native_scf_ao_work"][field]
        for side in ("baseline", "candidate"):
            row = next(item for item in record["diagnostic_rows"]
                       if item["workload"] == phase and item["selection"] == side)
            path = args.record.parent / Path(row["profile_file"]).name
            classes = rows(path)
            launches = rows(path.with_suffix(".launches.tsv"))
            assert len(launches) == row["force_launches"] == (2 if side == "baseline" else 3)
            expected_orders = [-2, 8] if side == "baseline" else [-3, 7, 8]
            for launch, expected_order in zip(launches, expected_orders, strict=True):
                if expected_order == 7:
                    assert "direct_order_seven_force_kernel<" in launch["symbol"]
                    assert launch["class_major"] == "1"
                    candidates = int(launch["class_candidate_pairs"])
                    assert candidates > 0
                    assert candidates <= int(launch["candidate_slots_upper"])
                    assert int(launch["candidate_slots_upper"]) < candidates + 32 * int(launch["class_bra_pairs"])
                else:
                    match = re.search(r"kernel<[^,]+,[^,]+,[^,]+,\s*(-?\d+),", launch["symbol"])
                    assert match and int(match.group(1)) == expected_order
                    assert launch["class_major"] == "0" and int(launch["outer_products"]) > 0
                assert launch["resident"] == "0" and launch["maximum_shell_angular"] == "2"
                assert int(launch["cooperative_selected"]) == (side == "candidate")
                assert int(launch["logical_outer_pages"]) > 0
            domains = {(launch["indexed_domain"], launch["outer_products"],
                        launch["logical_outer_pages"], launch["candidate_slots_upper"]) for launch in launches
                       if launch["class_major"] == "0"}
            assert len(domains) == 1
            arms[side] = {
                "class_rows": sorted(tuple(int(item[field]) for field in scientific_fields) for item in classes),
                "domain": next(iter(domains)),
                "worker_ms": {str(order): float(launch["worker_ms"])
                              for order, launch in zip(expected_orders, launches, strict=True)},
                "logical_outer_pages_sum": sum(int(launch["logical_outer_pages"]) for launch in launches),
                "candidate_slots_upper_sum": sum(int(launch["candidate_slots_upper"]) for launch in launches),
                "profile_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                "class_major_launches": [launch for launch in launches if launch["class_major"] == "1"],
            }
        assert arms["baseline"]["class_rows"] == arms["candidate"]["class_rows"]
        assert arms["baseline"]["domain"] == arms["candidate"]["domain"]
        class_launch, = arms["candidate"]["class_major_launches"]
        assert arms["candidate"]["logical_outer_pages_sum"] == arms["baseline"]["logical_outer_pages_sum"] + int(class_launch["logical_outer_pages"])
        assert arms["candidate"]["candidate_slots_upper_sum"] == arms["baseline"]["candidate_slots_upper_sum"] + int(class_launch["candidate_slots_upper"])
        assert 2 * arms["candidate"]["logical_outer_pages_sum"] < 3 * arms["baseline"]["logical_outer_pages_sum"]
        for side in arms:
            arms[side]["totals"] = {
                field: sum(row[index] for row in arms[side]["class_rows"])
                for index, field in enumerate(scientific_fields[1:4], 1)
            }
        results[phase] = arms
    result = {
        "status": "pass", "scope": "intrusive diagnostic only; not promotion timing",
        "record_sha256": hashlib.sha256(args.record.read_bytes()).hexdigest(),
        "complete_calls": len(calls), "cross_owner_identical_blobs": seed_scope,
        "energy_error_max_eh": max(item[0] for item in errors),
        "force_error_max_eh_per_bohr": max(item[1] for item in errors), "phases": results,
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("record", type=Path)
    parser.add_argument("reference", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    main(parser.parse_args())
