// Qualification-only observer. Clean samples disable interception and pass through.
// The bounded worker's existing optional profile records actual admissions. The
// resident psss worker has no profile parameter, so a separate probe reuses its
// exact device screening predicate on the same immutable arguments. Probe time
// is excluded from the worker event interval and all profiled wall times are
// diagnostic only. Total-force execution synchronizes and is never captured.
#include <cuda_runtime.h>
#include <cxxabi.h>
#include <dlfcn.h>

#include <array>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <memory>
#include <mutex>
#include <sstream>
#include <string>
#include <vector>

#include "generated_direct_resident_psss_schedule.cuh"
#include "scf/direct_block_domain.hpp"
#include "scf/direct_task_layout.hpp"
#include "scf/cuda/direct_queue_profile.cuh"
#include "scf/cuda/direct_order_seven_pages.cuh"
#include "scf/cuda/direct_screening.cuh"
#include "scf/cuda/packed_basis.hpp"

using namespace generativeqc::scf::cuda_execution;
constexpr auto classes = generativeqc::scf::detail::kDirectQuartetShellClassCount;
constexpr unsigned capacity = 512;

struct Record {
  std::string symbol;
  cudaEvent_t first{}, last{};
  cudaError_t status{};
  DeviceShellClassProfileEntry* profile{};
  dim3 grid{}, block{};
  cudaFuncAttributes attributes{};
  int active_blocks{};
  std::size_t dynamic_shared_bytes{};
  unsigned radial{};
  bool resident{};
  std::uint64_t outer_products{}, outer_pages{}, candidate_slots_upper{};
  unsigned maximum_shell_angular{};
  bool cooperative_selected{}, indexed_domain{};
  bool class_major{};
  std::uint64_t class_candidate_pairs{}, class_bra_pairs{}, class_ket_pairs{};
};
static std::mutex mutex;
static std::vector<std::unique_ptr<Record>> records;
static DeviceShellClassProfileEntry* profiles{};
static unsigned sample_count{};
static bool profiling_enabled{};
extern "C" void qc_force_profile_enable(bool enabled) { profiling_enabled = enabled; }
extern "C" std::size_t qc_force_profile_launch_count() {
  std::lock_guard<std::mutex> guard(mutex);
  return records.size();
}

static void check(cudaError_t status) {
  if (status != cudaSuccess) {
    std::fprintf(stderr, "force work observer: %s\n", cudaGetErrorString(status));
    std::abort();
  }
}

// Count precisely the shell/AO domain admitted by the resident worker; reuse
// production screening and counter definitions rather than reconstructing
// density maxima on the host. This probe produces no scientific output.
template <bool Unrestricted>
__global__ void profile_resident_psss(
    DeviceBatch batch, const PsssResidentTask* tasks, const std::uint32_t* ket_pairs,
    std::size_t task_count, double screening, const double* shell_bounds,
    const ShellPairDensityBounds* density_bounds, bool force_screening,
    const std::uint8_t* active, DeviceShellClassProfileEntry* profile) {
  if (blockIdx.x >= task_count) return;
  const auto task = tasks[blockIdx.x];
  const auto bra = task.bra_pair;
  if (!active[batch.shell_pair_systems[bra]]) return;
  const auto a = batch.shell_pair_first[bra], b = batch.shell_pair_second[bra];
  if (batch.shell_angular[a] + batch.shell_angular[b] != 1U) return;
  const auto primitive_count = batch.shell_pair_primitive_offsets[bra + 1] -
                               batch.shell_pair_primitive_offsets[bra];
  if (primitive_count <= 0 ||
      primitive_count > static_cast<std::int64_t>(kResidentPsssMaximumBraPrimitivePairs)) return;
  for (std::size_t local = threadIdx.x; local < task.ket_count; local += blockDim.x) {
    const auto ket = ket_pairs[task.ket_begin + local];
    const auto first = bra > ket ? bra : ket, second = bra > ket ? ket : bra;
    const bool admitted = force_screening
        ? direct_shell_quartet_survives_screening<Unrestricted, DirectScreeningPurpose::Force>(
              batch, first, second, screening, shell_bounds, density_bounds)
        : direct_shell_quartet_survives_screening<Unrestricted, DirectScreeningPurpose::Fock>(
              batch, first, second, screening, shell_bounds, density_bounds);
    if (admitted) profile_bounded_direct_shell_quartet(batch, {first, second, 0}, profile);
  }
}

extern "C" void qc_force_profile_initialize() {
  check(cudaMalloc(&profiles, capacity * classes * sizeof(*profiles)));
}

extern "C" cudaError_t cudaLaunchKernel(const void* function, dim3 grid, dim3 block,
                                        void** arguments, size_t shared, cudaStream_t stream) {
  using Launch = cudaError_t (*)(const void*, dim3, dim3, void**, size_t, cudaStream_t);
  static auto launch = reinterpret_cast<Launch>(dlsym(RTLD_NEXT, "cudaLaunchKernel"));
  if (!profiling_enabled) return launch(function, grid, block, arguments, shared, stream);
  Dl_info info{};
  if (!dladdr(function, &info) || !info.dli_sname)
    return launch(function, grid, block, arguments, shared, stream);
  int demangle_status{};
  char* demangled = abi::__cxa_demangle(info.dli_sname, nullptr, nullptr, &demangle_status);
  const std::string symbol = demangled ? demangled : info.dli_sname;
  std::free(demangled);
  const auto start = symbol.find("bounded_direct_shell_quartet_kernel<");
  bool bounded = false;
  if (start != std::string::npos) {
    auto fields = symbol.substr(start + std::string("bounded_direct_shell_quartet_kernel<").size());
    std::istringstream input(fields.substr(0, fields.find('>')));
    std::string field;
    std::getline(input, field, ',');  // Unrestricted
    std::getline(input, field, ',');  // Purpose
    std::getline(input, field, ',');  // Force
    bounded = field.find("true") != std::string::npos;
  }
  const bool resident = symbol.find("two_electron_force_psss_resident_bra_kernel<") != std::string::npos;
  const bool class_major = symbol.find("direct_order_seven_force_kernel<") != std::string::npos;
  if (!bounded && !resident && !class_major)
    return launch(function, grid, block, arguments, shared, stream);
  std::lock_guard<std::mutex> guard(mutex);
  if (!profiles || records.size() == capacity) std::abort();
  cudaStreamCaptureStatus capture{};
  check(cudaStreamIsCapturing(stream, &capture));
  if (capture != cudaStreamCaptureStatusNone) std::abort();
  auto record = std::make_unique<Record>();
  auto& r = *record;
  r.symbol = symbol; r.grid = grid; r.block = block; r.resident = resident;
  r.dynamic_shared_bytes = shared;
  r.class_major = class_major;
  r.profile = profiles + records.size() * classes;
  check(cudaMemsetAsync(r.profile, 0, classes * sizeof(*profiles), stream));
  check(cudaFuncGetAttributes(&r.attributes, function));
  check(cudaOccupancyMaxActiveBlocksPerMultiprocessor(
      &r.active_blocks, function, block.x * block.y * block.z, shared));
  std::vector<void*> forwarded(arguments, arguments + (bounded ? 24 : class_major ? 16 : 15));
  if (bounded) {
    // Frozen candidate ABI, verified against direct_bounded_fallback.cu. Only
    // replace a null optional profile argument; scientific arguments are intact.
    if (*static_cast<DeviceShellClassProfileEntry**>(arguments[15])) std::abort();
    forwarded[15] = &r.profile;
    r.radial = *static_cast<unsigned*>(arguments[18]);
    const auto batch = *static_cast<DeviceBatch*>(arguments[0]);
    const auto domain = *static_cast<generativeqc::scf::detail::BoundedDirectBlockDomain*>(arguments[23]);
    r.maximum_shell_angular = batch.direct_maximum_shell_angular;
    r.cooperative_selected = batch.direct_pair_cooperative_derivatives;
    r.indexed_domain = domain.prefix != nullptr;
    r.outer_products = r.indexed_domain ? domain.quartet_count : batch.total_shell_pair_block_quartets;
    const auto pages_per_product = r.indexed_domain
        ? generativeqc::scf::detail::kBoundedDirectIndexedCandidatePages : 1U;
    r.outer_pages = r.outer_products * pages_per_product;
    constexpr auto block_size = generativeqc::scf::detail::kBoundedDirectShellPairBlockSize;
    r.candidate_slots_upper = r.outer_products * block_size * block_size;
  } else if (class_major) {
    // Qualification-only readback of immutable descriptor counts. This is
    // outside the worker event interval and never enters clean timing.
    if (*static_cast<DeviceShellClassProfileEntry**>(arguments[13])) std::abort();
    forwarded[13] = &r.profile;
    const auto batch = *static_cast<DeviceBatch*>(arguments[0]);
    const auto topology_pointer = *static_cast<const GeneratedShellPairStream**>(arguments[1]);
    GeneratedShellPairStream topology{};
    check(cudaMemcpyAsync(&topology, topology_pointer, sizeof(topology), cudaMemcpyDeviceToHost, stream));
    check(cudaStreamSynchronize(stream));
    if (topology.batch_size != batch.batch_size || !topology.pair_class_offsets ||
        !topology.pair_order || topology.shell_pair_first != batch.shell_pair_first ||
        topology.shell_pair_second != batch.shell_pair_second ||
        topology.shell_angular != batch.shell_angular) std::abort();
    const auto stride = static_cast<std::size_t>(batch.batch_size) + 1U;
    std::vector<std::uint32_t> offsets(10U * stride);
    check(cudaMemcpyAsync(offsets.data(), topology.pair_class_offsets, offsets.size() * sizeof(offsets[0]),
                          cudaMemcpyDeviceToHost, stream));
    check(cudaStreamSynchronize(stream));
    for (std::size_t system = 0; system < static_cast<std::size_t>(batch.batch_size); ++system) {
      const std::uint64_t bra = offsets[kDirectDdPairClass * stride + system + 1U] -
                                offsets[kDirectDdPairClass * stride + system];
      const std::uint64_t ket = offsets[kDirectDpPairClass * stride + system + 1U] -
                                offsets[kDirectDpPairClass * stride + system];
      r.class_bra_pairs += bra; r.class_ket_pairs += ket;
      r.class_candidate_pairs += bra * ket;
      r.outer_pages += bra * ((ket + kDirectOrderSevenKetPageSize - 1U) / kDirectOrderSevenKetPageSize);
    }
    r.candidate_slots_upper = r.outer_pages * kDirectOrderSevenKetPageSize;
    r.maximum_shell_angular = batch.direct_maximum_shell_angular;
    r.cooperative_selected = batch.direct_pair_cooperative_derivatives;
    r.radial = symbol.find("DirectForceOutputMode)1") == std::string::npos ? 0U : 4U;
  } else {
    const bool unrestricted = symbol.find("kernel<true,") != std::string::npos;
    const auto batch = *static_cast<DeviceBatch*>(arguments[0]);
    const auto tasks = *static_cast<const PsssResidentTask**>(arguments[1]);
    const auto ket = *static_cast<const std::uint32_t**>(arguments[2]);
    const auto count = *static_cast<std::size_t*>(arguments[3]);
    const auto screening = *static_cast<double*>(arguments[4]);
    const auto shell = *static_cast<const double**>(arguments[5]);
    const auto density = *static_cast<const ShellPairDensityBounds**>(arguments[6]);
    const auto force = *static_cast<bool*>(arguments[7]);
    const auto active = *static_cast<const std::uint8_t**>(arguments[10]);
    if (unrestricted)
      profile_resident_psss<true><<<grid, block, 0, stream>>>(
          batch, tasks, ket, count, screening, shell, density, force, active, r.profile);
    else
      profile_resident_psss<false><<<grid, block, 0, stream>>>(
          batch, tasks, ket, count, screening, shell, density, force, active, r.profile);
    check(cudaGetLastError());
  }
  check(cudaEventCreate(&r.first)); check(cudaEventCreate(&r.last));
  check(cudaEventRecord(r.first, stream));
  r.status = launch(function, grid, block, forwarded.data(), shared, stream);
  check(cudaEventRecord(r.last, stream));
  records.push_back(std::move(record));
  return r.status;
}

extern "C" void qc_force_profile_sample() {
  std::lock_guard<std::mutex> guard(mutex);
  check(cudaDeviceSynchronize());
  const auto sample_prefix = std::string(std::getenv("QC_FORCE_PROFILE_OUTPUT")) + "-" +
                             std::to_string(sample_count++);
  std::ofstream output(sample_prefix + ".tsv");
  std::ofstream launch_output(sample_prefix + ".launches.tsv");
  // These are actual launch descriptors, not GPU claim counters. The candidate
  // slot bound includes rejected orientations, inactive pages and padded tails.
  launch_output << "launch\tworker_ms\tresident\tmaximum_shell_angular\tcooperative_selected\tindexed_domain\t"
                   "outer_products\tlogical_outer_pages\tcandidate_slots_upper\tclass_major\t"
                   "class_candidate_pairs\tclass_bra_pairs\tclass_ket_pairs\tsymbol\n";
  output << "launch\tclass\tshell_quartets\tao_quartets\tprimitive_ao_quartets\ttiles\t"
            "worker_ms\tradial\tresident\tgrid\tblock\tregisters\tstatic_shared_bytes\tdynamic_shared_bytes\t"
            "local_bytes\tactive_blocks_per_sm\tsymbol\n";
  unsigned index{};
  for (const auto& p : records) {
    auto& r = *p;
    check(r.status);
    float milliseconds{};
    check(cudaEventElapsedTime(&milliseconds, r.first, r.last));
    launch_output << index << '\t' << milliseconds << '\t' << r.resident << '\t'
                  << r.maximum_shell_angular << '\t' << r.cooperative_selected << '\t'
                  << r.indexed_domain << '\t' << r.outer_products << '\t' << r.outer_pages << '\t'
                  << r.candidate_slots_upper << '\t' << r.class_major << '\t'
                  << r.class_candidate_pairs << '\t' << r.class_bra_pairs << '\t'
                  << r.class_ket_pairs << '\t' << r.symbol << '\n';
    std::array<DeviceShellClassProfileEntry, classes> entries{};
    check(cudaMemcpy(entries.data(), r.profile, sizeof(entries), cudaMemcpyDeviceToHost));
    for (unsigned c = 0; c < classes; ++c) {
      const auto e = entries[c];
      if (!e.shell_quartets) continue;
      output << index << '\t' << c << '\t' << e.shell_quartets << '\t' << e.ao_quartets << '\t'
             << e.primitive_quartets << '\t' << e.tiles << '\t' << milliseconds << '\t'
             << r.radial << '\t' << r.resident << '\t' << r.grid.x << ',' << r.grid.y << ',' << r.grid.z
             << '\t' << r.block.x << ',' << r.block.y << ',' << r.block.z << '\t'
             << r.attributes.numRegs << '\t' << r.attributes.sharedSizeBytes << '\t'
             << r.dynamic_shared_bytes << '\t' << r.attributes.localSizeBytes << '\t' << r.active_blocks << '\t' << r.symbol << '\n';
    }
    check(cudaEventDestroy(r.first)); check(cudaEventDestroy(r.last));
    ++index;
  }
  records.clear();
}
