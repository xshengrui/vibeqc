#!/usr/bin/env bash
set -euo pipefail
export NEXT_VARIANT=candidate-force7-class-master-v1
unset VARIANT
source /data/jzzeng/qc-next-hotspot-20261009-125a4e33f/env-next.sh
: "${SLURM_JOB_ID:?}" "${CUDA_VISIBLE_DEVICES:?}"
export EVIDENCE="$ROOT/evidence/force7-class-master-v1/sanitizer"
mkdir -p "$EVIDENCE"
test -f "$ROOT/evidence/force7-class-master-v1/final/current-integration-completed.txt"
test ! -f "$EVIDENCE/job.txt"
printf 'job=%s visibility=%s\n' "$SLURM_JOB_ID" "$CUDA_VISIBLE_DEVICES" > "$EVIDENCE/job.txt"
"$GENERATIVEQC_CCACHE" --version > "$EVIDENCE/cache-version.txt"
"$GENERATIVEQC_CCACHE" --show-stats > "$EVIDENCE/cache-before.txt"
command=("$GENERATIVEQC_CCACHE" /usr/bin/c++ -std=c++20 -O2 -fPIC
  -I"$CUDA_PATH/include" -c "$EVIDENCE/force-launch-observer.cpp" -o "$EVIDENCE/force-launch-observer.o")
printf '%q ' "${command[@]}" > "$EVIDENCE/compiler-command.txt"
printf '\n' >> "$EVIDENCE/compiler-command.txt"
timeout 120 "${command[@]}" > "$EVIDENCE/observer-build.log" 2>&1
timeout 60 /usr/bin/c++ -shared "$EVIDENCE/force-launch-observer.o" -ldl \
  -o "$EVIDENCE/force-launch-observer.so" >> "$EVIDENCE/observer-build.log" 2>&1
nm -D "$GENERATIVEQC_LIBRARY" | grep direct_order_seven_force_kernel > "$EVIDENCE/kernel-symbols.txt"
export GENERATIVEQC_RESOURCE_CUDA_TEST=1
export GENERATIVEQC_ONE_ELECTRON_DERIVATIVE_MAPPING=nucleus_cooperative
export GENERATIVEQC_DIRECT_PAIR_MATERIALIZED_DERIVATIVES=1
export GENERATIVEQC_DIRECT_PAIR_COOPERATIVE_DERIVATIVES=1
export GENERATIVEQC_BOUNDED_ANGULAR_FORCE=off
for tool in memcheck racecheck; do
  export QC_FORCE_LAUNCH_LOG="$EVIDENCE/$tool-launches.jsonl"
  LD_PRELOAD="$EVIDENCE/force-launch-observer.so:$LD_PRELOAD" \
    "$CUDA_PATH/bin/compute-sanitizer" --tool "$tool" --error-exitcode 87 \
      --target-processes all --kernel-name kernel_substring=direct_order_seven_force_kernel \
      "$PYTHON" -m pytest -q \
      tests/python/test_cuda_hybrid_snapshot.py::test_separate_full_range_derivatives_match_libcint \
      -k bounded-True-1-cartesian-pbe0-rks --basetemp "$EVIDENCE/$tool-tmp" \
      --junitxml "$EVIDENCE/$tool.xml" > "$EVIDENCE/$tool.log" 2>&1
  "$PYTHON" - "$EVIDENCE/$tool.xml" "$QC_FORCE_LAUNCH_LOG" <<'PY'
import json
import sys
import xml.etree.ElementTree as tree

cases = tree.parse(sys.argv[1]).getroot().findall(".//testcase")
assert len(cases) == 1 and not any(case.find(kind) is not None for case in cases for kind in ("skipped", "failure", "error"))
counts = [json.loads(line) for line in open(sys.argv[2])]
assert sum(item["class_launches"] for item in counts) >= 3, counts
print("Independent case executed; Separate/Combined/replay class kernels launched under sanitizer.")
PY
done
sha256sum "$GENERATIVEQC_LIBRARY" "$EVIDENCE/force-launch-observer.so" > "$EVIDENCE/identities.sha256"
"$GENERATIVEQC_CCACHE" --show-stats > "$EVIDENCE/cache-after.txt"
date -Iseconds > "$EVIDENCE/completed.txt"
