#!/usr/bin/env bash
set -euo pipefail
export NEXT_VARIANT=candidate-force7-class-explicit-v1
unset VARIANT
source /data/jzzeng/qc-next-hotspot-20261009-125a4e33f/env-next.sh
: "${SLURM_JOB_ID:?}" "${CUDA_VISIBLE_DEVICES:?}"
export EVIDENCE="$ROOT/evidence/force7-class-explicit-v1"
mkdir -p "$EVIDENCE"
test ! -f "$EVIDENCE/job.txt"
printf 'job=%s visibility=%s\n' "$SLURM_JOB_ID" "$CUDA_VISIBLE_DEVICES" > "$EVIDENCE/job.txt"
"$GENERATIVEQC_CCACHE" --version > "$EVIDENCE/cache-version.txt"
"$GENERATIVEQC_CCACHE" --show-stats > "$EVIDENCE/cache-before.txt"
cmake -S . -B build/cuda-release-sm120 -G Ninja \
  -DCMAKE_CXX_COMPILER_LAUNCHER="$GENERATIVEQC_CCACHE" \
  -DCMAKE_CUDA_COMPILER_LAUNCHER="$GENERATIVEQC_CCACHE" \
  > "$EVIDENCE/configure.log" 2>&1
ninja -C build/cuda-release-sm120 -t commands > "$EVIDENCE/compiler-commands.txt"
awk 'index($0, "one_electron_gradient_bridge.cu.o") && !printed {print; printed=1}' \
  "$EVIDENCE/compiler-commands.txt" > "$EVIDENCE/bridge-command.txt"
grep -F "$GENERATIVEQC_CCACHE" "$EVIDENCE/bridge-command.txt" >/dev/null
cmake --build build/cuda-release-sm120 --parallel 16 --target generativeqc \
  > "$EVIDENCE/build.log" 2>&1
sha256sum src/scf/cuda/one_electron_gradient_bridge.cu "$GENERATIVEQC_LIBRARY" \
  > "$EVIDENCE/identities.sha256"
"$GENERATIVEQC_CCACHE" --show-stats > "$EVIDENCE/cache-after-build.txt"
date -Iseconds > "$EVIDENCE/build-completed.txt"
export GENERATIVEQC_RESOURCE_CUDA_TEST=1
for selection in default explicit; do
  if [[ "$selection" == default ]]; then
    unset GENERATIVEQC_ONE_ELECTRON_DERIVATIVE_MAPPING
    export GENERATIVEQC_DIRECT_PAIR_COOPERATIVE_DERIVATIVES=0
  else
    export GENERATIVEQC_ONE_ELECTRON_DERIVATIVE_MAPPING=nucleus_cooperative
    export GENERATIVEQC_DIRECT_PAIR_COOPERATIVE_DERIVATIVES=1
  fi
  "$PYTHON" -m pytest -q \
    tests/python/test_cuda_hybrid_snapshot.py::test_cuda_hybrid_snapshot_matches_cpu_composition_and_state \
    -k pbe0 --basetemp "$EVIDENCE/$selection-tmp" \
    --junitxml "$EVIDENCE/$selection.xml" > "$EVIDENCE/$selection.log" 2>&1
done
"$PYTHON" - "$EVIDENCE" <<'PY'
import sys
import xml.etree.ElementTree as tree
from pathlib import Path

for selection in ("default", "explicit"):
    cases = tree.parse(Path(sys.argv[1]) / f"{selection}.xml").getroot().findall(".//testcase")
    assert len(cases) == 2
    assert not any(case.find(kind) is not None for case in cases for kind in ("skipped", "failure", "error"))
    print(selection, "two executed PBE0 RKS/UKS CPU-composition snapshot passes, no skips")
PY
"$GENERATIVEQC_CCACHE" --show-stats > "$EVIDENCE/cache-after-gate.txt"
date -Iseconds > "$EVIDENCE/completed.txt"
