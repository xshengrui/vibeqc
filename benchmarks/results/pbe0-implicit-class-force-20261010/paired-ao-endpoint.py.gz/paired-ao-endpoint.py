"""Paired complete E+F calls with immutable native force policies per owner.

Native integral schedules are captured by the SCF/Fock owner. Reconstructing
only its Python gradient executor cannot legally switch them. Each worker
therefore owns an independently converged, publicly frozen native warm seed;
no byte-identical seed or cold/moved timing comparison is claimed. Only one
owner submits GPU work at a time on the unchanged Slurm-assigned device. The
incumbent comparison shares one CUDA context, avoiding two runtime stack heaps.
Angular selection is captured at native owner construction, never reconfigured
on a live owner; Python force policies remain identical throughout.
"""

from __future__ import annotations

import argparse
import ctypes as ct
import hashlib
import importlib.util
import json
import os
import select
import subprocess
import sys
import traceback
from pathlib import Path
from time import perf_counter
from typing import Any

import numpy as np
from generativeqc_compiler.common.evidence import canonical_hash
from generativeqc_compiler.common.performance import assess_comparison
from generativeqc_compiler.common.timing import interleaved_selection_order


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def isolated_baseline_factory(root: Path) -> Any:
    """Load frozen compiler functions without replacing shared scientific types."""
    modules = {}
    for package, filename in (
        ("common", "paths.py"),
        ("method", "stationary_cuda.py"),
    ):
        path = root / "python/generativeqc_compiler" / package / filename
        name = f"generativeqc_compiler.{package}._frozen_ao_baseline"
        specification = importlib.util.spec_from_file_location(name, path)
        assert specification is not None and specification.loader is not None
        module = importlib.util.module_from_spec(specification)
        sys.modules[name] = module
        specification.loader.exec_module(module)
        modules[package] = module
    baseline = modules["method"]
    baseline.asset_path = modules["common"].asset_path
    baseline.source_hashes = modules["common"].source_hashes
    from generativeqc_compiler.method import stationary_cuda as candidate

    families = ("common", "integral", "tensor", "xc", "dft", "method")
    before = baseline.source_hashes(*families, assets=baseline.STATIONARY_AOT_ASSETS)
    after = candidate.source_hashes(*families, assets=candidate.STATIONARY_AOT_ASSETS)
    differences = {name for name in before.keys() | after.keys() if before.get(name) != after.get(name)}
    assert differences == {
        "python/generativeqc_compiler/method/stationary_cuda.py",
        "src/dft/stationary_gradient_cuda.cuh",
    }, differences
    return baseline


def make_owner(args: argparse.Namespace, shared: dict[str, Any]) -> Any:
    """Keep one complete native owner and never reconfigure its live policy."""
    import cupy as cp
    from generativeqc import Calculator, GridSpec, KsOptions

    from benchmarks._support import cuda_accelerator_metadata
    from benchmarks.compare_gpu4pyscf_batch import (
        native_build_metadata,
        require_tuned_native_build,
    )
    from benchmarks.dft_force_components import normalize_force_work
    from benchmarks.ks_preliminary_density import read_ao_work
    from benchmarks.readme_hf_scaling import scaling_cases
    from benchmarks.readme_omol25 import load_comparison_basis, protocol, source_hashes
    from benchmarks.readme_pbe0 import PBE0

    assert os.environ.get("SLURM_JOB_ID") and os.environ.get("CUDA_VISIBLE_DEVICES")
    reference = json.loads(args.reference.read_text())
    basis, _ = load_comparison_basis(
        args.basis_file,
        scaling_cases()[f"water-{args.atoms}"],
        role="orbital",
        compute_forces=True,
    )
    grid = GridSpec(radial_points=48, angular_polar=16, angular_azimuth=32)
    scientific = protocol(args.atoms, basis, grid, 5, benchmark=PBE0)
    assert scientific == reference["protocol"]
    calculator = Calculator(
        method="pbe0-rks",
        basis=basis,
        device="cuda",
        basis_representation="spherical",
        ks_options=KsOptions(grid=grid),
        energy_tolerance=1e-12,
        density_tolerance=1e-10,
        screening_tolerance=1e-12,
        max_iterations=100,
    )
    build = native_build_metadata(calculator)
    require_tuned_native_build(build)
    angular_control = os.environ["GENERATIVEQC_BOUNDED_ANGULAR_FORCE"]
    native_settings = {
        name: value
        for name, value in sorted(os.environ.items())
        if name.startswith("GENERATIVEQC_") and name != "GENERATIVEQC_LIBRARY"
    }
    owner = calculator.prepare_batch(
        [scientific["geometries_bohr"][0]], warm_start=True
    )
    original = owner._public_dft_cuda_force
    work = None
    geometry = 0

    def observed(*values: Any) -> Any:
        nonlocal work
        try:
            result = original(*values)
        except Exception as error:
            detail = owner._library.generativeqc_context_get_last_detail(owner._context)
            raise RuntimeError(f"{error}; native detail: {detail!r}") from error
        work = result[1]
        return result

    def execute(*, setup: bool = False) -> dict[str, Any]:
        nonlocal work
        coords = (
            None
            if geometry == 0
            else [np.asarray([xyz for _, xyz in scientific["geometries_bohr"][1]])]
        )
        work = None
        cp.cuda.Stream.null.synchronize()
        start = perf_counter()
        item = owner.execute(
            coords, strict=True, properties=("energy", "forces")
        ).items[0]
        cp.cuda.Stream.null.synchronize()
        seconds = perf_counter() - start
        assert item.status == 0 and item.converged, item.status_message
        assert item.forces is not None, item.status_message
        oracle = next(
            row
            for row in reference["records"]
            if row["geometry"] == geometry and row["phase"] in ("cold", "moved")
        )
        energy_error = abs(item.energy - oracle["energy"])
        force_error = float(np.max(np.abs(np.asarray(item.forces) - oracle["forces"])))
        assert energy_error <= 1e-8 and force_error <= 1e-7
        if not setup:
            assert item.iterations == item.fock_builds == 1
            assert item.warm_start_used and not item.warm_start_fallback
        assert work is not None
        normalized = normalize_force_work(work)
        becke = normalized["becke_owners"]["stationary"]
        assert not becke["profile_enabled"] and not becke["profile_intrusive"]
        assert becke["selection"]["becke_primitive_selected"] == 0
        bounds = normalized["resource_bounds"]
        assert (
            bounds["additional_device_peak_bound"] <= bounds["additional_device_budget"]
        )
        assert (
            bounds["additional_host_numeric_bound"] <= bounds["additional_host_budget"]
        )
        return {
            "seconds": seconds,
            "geometry": geometry,
            "diagnostics": {
                "energy": item.energy,
                "forces": np.asarray(item.forces).tolist(),
                "energy_error_eh": energy_error,
                "force_error_eh_per_bohr": force_error,
                "status": item.status,
                "converged": item.converged,
                "iterations": item.iterations,
                "fock_builds": item.fock_builds,
                "warm_start_used": item.warm_start_used,
                "warm_start_fallback": item.warm_start_fallback,
                "native_ks_diagnostic": item.ks_diagnostic.to_payload(),
                "native_force_components": normalized,
                "native_scf_ao_work": read_ao_work(owner),
            },
        }

    owner._public_dft_cuda_force = observed
    # Fully materialize the native Fock/force lease before another owner is
    # constructed under its own angular selection. Retain this complete call.
    bootstrap = execute(setup=True)
    owner.set_warm_start_updates(False)

    def close() -> None:
        owner._public_dft_cuda_force = original
        owner.close()

    def handle(command: dict[str, Any]) -> dict[str, Any]:
        nonlocal geometry
        action = command["action"]
        if action == "metadata":
            root = Path(owner._library._name).resolve().parents[2]
            return {
                "protocol": scientific,
                "native_build": build,
                "source_file_sha256": {
                    **source_hashes(),
                    **{
                        path: digest(root / path)
                        for path in (
                            "src/scf/cuda/direct_bounded_fallback.cu",
                            "src/scf/cuda/direct_bounded_fallback.hpp",
                            "src/scf/cuda/direct_coulomb.cpp",
                            "src/scf/cuda/direct_jk_kernels.cu",
                            "src/scf/cuda/direct_jk_kernels.hpp",
                        )
                    },
                    "paired-driver": digest(Path(__file__)),
                },
                "accelerator": cuda_accelerator_metadata(cp),
                "angular_control": angular_control,
                "native_schedule_settings": native_settings,
                "construction_initialization": bootstrap,
                "free_device_bytes_after_owner_construction": cp.cuda.runtime.memGetInfo()[
                    0
                ],
            }
        if action == "setup":
            geometry = command["geometry"]
            owner.set_warm_start_updates(True)
            result = execute(setup=True)
            owner.set_warm_start_updates(False)
            return result
        if action in {"prime", "evaluate"}:
            assert not owner._warm_updates
            return execute()
        if action == "diagnostic":
            if "observer" not in shared:
                observer = ct.CDLL(None)
                observer.qc_force_profile_enable.argtypes = [ct.c_bool]
                observer.qc_force_profile_initialize()
                observer.qc_force_profile_launch_count.restype = ct.c_size_t
                shared.update(observer=observer, sample_count=0)
            observer = shared["observer"]
            os.environ["QC_FORCE_PROFILE_OUTPUT"] = command["profile_prefix"]
            observer.qc_force_profile_enable(True)
            observer.qc_geometry_observer_start.argtypes = [ct.c_char_p]
            geometry_prefix = f"{command['profile_prefix']}-{shared['sample_count']}"
            observer.qc_geometry_observer_start(geometry_prefix.encode())
            try:
                result = execute()
                result["force_launches"] = observer.qc_force_profile_launch_count()
                result["profile_file"] = (
                    f"{command['profile_prefix']}-{shared['sample_count']}.tsv"
                )
                observer.qc_force_profile_sample()
                shared["sample_count"] += 1
                return result
            finally:
                observer.qc_geometry_observer_finish()
                observer.qc_force_profile_enable(False)
        raise ValueError(action)

    return handle, close


def worker(args: argparse.Namespace) -> None:
    """One context can retain distinct owners, not two runtime stack heaps."""
    reply = os.fdopen(args.reply_fd, "w", buffering=1)
    owners = {}
    shared: dict[str, Any] = {}
    try:
        from generativeqc import _stationary_cuda as runtime
        from generativeqc_compiler.method import stationary_cuda as candidate_factory

        factories = {
            "baseline": isolated_baseline_factory(args.root / "baseline"),
            "candidate": candidate_factory,
        }
        for message in sys.stdin:
            command = json.loads(message)
            if command["action"] == "close":
                reply.write(json.dumps({"result": {"closed": True}}) + "\n")
                break
            selection = command["selection"] if args.shared_worker else "worker"
            factory = factories[selection]
            runtime.compile_stationary_cuda = factory.compile_stationary_cuda
            runtime.load_stationary_aot_artifact = factory.load_stationary_aot_artifact
            if args.shared_worker:
                # Geometry rebuilds may construct a fresh native force lease.
                # Apply the same immutable selection whenever this owner is
                # active; never let the other owner's ambient policy leak in.
                os.environ["GENERATIVEQC_BOUNDED_ANGULAR_FORCE"] = (
                    "off"
                    if args.compare in {"materialized", "ao-reduction"}
                    or selection == "baseline"
                    and args.compare == "incumbent"
                    else "angular"
                )
                source = args.root / (
                    "baseline"
                    if selection == "baseline"
                    and args.compare in {"angular", "materialized", "ao-reduction"}
                    else args.candidate_variant
                )
                os.environ["GENERATIVEQC_LIBRARY"] = str(
                    source / "build/cuda-release-sm120/libgenerativeqc.so"
                )
            if selection not in owners:
                owners[selection] = make_owner(args, shared)
            result = owners[selection][0](command)
            if command["action"] == "metadata":
                source = args.root / ("baseline" if selection == "baseline" else args.candidate_variant)
                generator = "python/generativeqc_compiler/method/stationary_cuda.py"
                header = "src/dft/stationary_gradient_cuda.cuh"
                package = source / "build/cuda-release-sm120"
                result["source_file_sha256"][generator] = digest(source / generator)
                result["source_file_sha256"][header] = digest(source / header)
                result["stationary_factory"] = {
                    "source_sha256": digest(source / generator),
                    "runtime_header_sha256": digest(source / header),
                    "aot_manifest_sha256": digest(package / "generativeqc_stationary_pbe0_rks_spd.json"),
                    "aot_library_sha256": digest(package / "libgenerativeqc_stationary_pbe0_rks_spd.so"),
                    "aot_library_path": str((package / "libgenerativeqc_stationary_pbe0_rks_spd.so").resolve()),
                    "isolation": "frozen baseline generator/runtime header/path inventory; all other compiler input bytes equal",
                }
            reply.write(json.dumps({"result": result}) + "\n")
    except BaseException:
        reply.write(json.dumps({"error": traceback.format_exc()}) + "\n")
        raise
    finally:
        for _, close in owners.values():
            close()
        reply.close()


class Client:
    """Use a dedicated reply pipe, separate from native/compiler stdout."""

    def __init__(self, args: argparse.Namespace, selection: str) -> None:
        source_variant = (
            "baseline"
            if selection == "baseline" and args.compare == "angular"
            else args.candidate_variant
        )
        source = args.root / source_variant
        environment = os.environ.copy()
        environment["PYTHONPATH"] = f"{source / 'python'}:{source}"
        environment["GENERATIVEQC_LIBRARY"] = str(
            source / "build/cuda-release-sm120/libgenerativeqc.so"
        )
        environment["LD_LIBRARY_PATH"] = ":".join(
            [
                str(source / "build/cuda-release-sm120"),
                *environment["LD_LIBRARY_PATH"].split(":")[1:],
            ]
        )
        environment["GENERATIVEQC_BOUNDED_ANGULAR_FORCE"] = (
            "off"
            if selection == "baseline" and args.compare == "incumbent"
            else "angular"
        )
        environment["GENERATIVEQC_STATIONARY_BECKE_PRIMITIVE"] = "off"
        if args.observer:
            environment["LD_PRELOAD"] = f"{args.observer}:{environment['LD_PRELOAD']}"
            environment["QC_FORCE_PROFILE_OUTPUT"] = (
                str(args.output.with_suffix("")) + f"-{selection}-force"
            )
        read_fd, write_fd = os.pipe()
        self.reply = os.fdopen(read_fd)
        self.log = args.output.with_suffix(f".{selection}.log").open("w")
        self.process = subprocess.Popen(
            [
                sys.executable,
                str(Path(__file__).resolve()),
                "--worker",
                *(["--shared-worker"] if selection == "shared" else []),
                "--root",
                str(args.root),
                "--compare",
                args.compare,
                "--candidate-variant",
                args.candidate_variant,
                "--reply-fd",
                str(write_fd),
                "--atoms",
                str(args.atoms),
                "--reference",
                str(args.reference),
                "--basis-file",
                str(args.basis_file),
            ],
            cwd=source,
            env=environment,
            stdin=subprocess.PIPE,
            stdout=self.log,
            stderr=subprocess.STDOUT,
            text=True,
            pass_fds=(write_fd,),
        )
        os.close(write_fd)

    def request(self, action: str, **arguments: Any) -> Any:
        assert self.process.stdin is not None
        self.process.stdin.write(json.dumps({"action": action, **arguments}) + "\n")
        self.process.stdin.flush()
        assert select.select([self.reply], [], [], 600)[0], "worker timeout"
        response = self.reply.readline()
        assert response, f"worker exited {self.process.poll()}"
        result = json.loads(response)
        assert "error" not in result, result.get("error")
        return result["result"]

    def close(self) -> None:
        """Release a failed worker too, without obscuring its primary error."""
        try:
            if self.process.poll() is None:
                self.request("close")
                self.process.wait(timeout=30)
            assert self.process.returncode == 0
        finally:
            if self.process.poll() is None:
                self.process.terminate()
                self.process.wait(timeout=30)
            self.reply.close()
            self.log.close()


def main(args: argparse.Namespace) -> None:
    """Retain every setup, priming, measured and diagnostic complete call."""
    assert os.environ.get("SLURM_JOB_ID") and os.environ.get("CUDA_VISIBLE_DEVICES")
    assert args.repeats >= 5 or args.feasibility and args.repeats == 1
    record: dict[str, Any] = {
        "schema": "generativeqc.angular-force-paired-endpoint.v1",
        "status": "running",
        "compare": args.compare,
        "atoms": args.atoms,
        "job": os.environ["SLURM_JOB_ID"],
        "visibility": os.environ["CUDA_VISIBLE_DEVICES"],
        "reference_sha256": digest(args.reference),
        "driver_sha256": digest(Path(__file__)),
        "paired_repeats": args.repeats,
        "feasibility": args.feasibility,
        "observer_sha256": digest(args.observer) if args.observer else None,
        "density_identity_scope": "independently converged native seeds, each publicly frozen; not byte-identical across arms",
        "profile_scope": "observer pass-through during timing; actual shell admission profiles collected in separate untimed calls only",
        "setup": [],
        "priming": [],
        "samples": [],
        "diagnostics": [],
        "assessments": {},
    }
    clients = {}

    def save(stage: str) -> None:
        record["stage"] = stage
        args.output.write_text(json.dumps(record, indent=2) + "\n")

    try:
        client = Client(args, "shared")
        clients = dict.fromkeys(("baseline", "candidate"), client)
        record["context_scope"] = (
            "one CUDA context, two independently prepared and immutable native angular policies"
        )
        record["arms"] = {
            side: client.request("metadata", selection=side)
            for side, client in clients.items()
        }
        record["protocol"] = record["arms"]["baseline"]["protocol"]
        assert record["protocol"] == record["arms"]["candidate"]["protocol"]
        # nvidia-smi clocks/temperature are observations, not device identity.
        for field in (
            "backend",
            "device_id",
            "name",
            "compute_capability",
            "total_global_memory_bytes",
            "multiprocessor_count",
            "driver_version",
            "runtime_version",
        ):
            assert (
                record["arms"]["baseline"]["accelerator"][field]
                == record["arms"]["candidate"]["accelerator"][field]
            )
        if args.compare == "incumbent":
            assert (
                record["arms"]["baseline"]["native_build"]["library_sha256"]
                == record["arms"]["candidate"]["native_build"]["library_sha256"]
            )
        for geometry, phase in enumerate(("warm", "moved-warm")):
            for selection, client in clients.items():
                row = client.request("setup", geometry=geometry, selection=selection)
                record["setup"].append({**row, "selection": selection})
                save(f"{phase}/setup-{selection}")
            input_hash = canonical_hash(
                {"protocol": record["protocol"], "geometry": geometry}
            )
            for selection in interleaved_selection_order(args.repeats):
                client = clients[selection]
                prime = client.request("prime", selection=selection)
                record["priming"].append(
                    {**prime, "selection": selection, "phase": phase}
                )
                row = client.request("evaluate", selection=selection)
                record["samples"].append(
                    {
                        **row,
                        "selection": selection,
                        "phase": phase,
                        "workload": "energy-plus-force",
                        "inputs_hash": input_hash,
                        "synchronized": True,
                    }
                )
                save(f"{phase}/sample-{len(record['samples'])}")
            samples = [row for row in record["samples"] if row["phase"] == phase]
            record["assessments"][phase] = (
                assess_comparison(samples)
                if not args.feasibility
                else {
                    "status": "not-run",
                    "reason": "one pair is feasibility only",
                }
            )
            if args.observer:
                for selection, client in clients.items():
                    row = client.request(
                        "diagnostic",
                        selection=selection,
                        profile_prefix=str(args.output.with_suffix(""))
                        + f"-{selection}-force",
                    )
                    record["diagnostics"].append(
                        {**row, "selection": selection, "phase": phase}
                    )
                    save(f"{phase}/diagnostic-{selection}")
                    expected_launches = 2 if args.compare == "ao-reduction" else (
                        (2 if selection == "candidate" else 1)
                        if args.compare == "materialized"
                        else (
                            9
                            if selection == "candidate"
                            else (1 if args.compare == "incumbent" else 13)
                        )
                    )
                    assert row["force_launches"] == expected_launches, (selection, row["force_launches"], expected_launches)
            save(f"{phase}/complete")
        record["status"] = "measured"
        save("complete")
    except BaseException:
        record["status"] = "failed"
        record["error"] = traceback.format_exc()
        save(record.get("stage", "initialization"))
        raise
    finally:
        cleanup_errors = []
        for client in dict.fromkeys(clients.values()):
            try:
                client.close()
            except (
                RuntimeError,
                AssertionError,
                OSError,
                subprocess.TimeoutExpired,
            ) as error:
                cleanup_errors.append(
                    {"kind": type(error).__name__, "error": traceback.format_exc()}
                )
        if cleanup_errors:
            record["cleanup_errors"] = cleanup_errors
            if record["status"] != "failed":
                record["status"] = "failed"
                record["error"] = "worker cleanup failed"
            save(record.get("stage", "cleanup"))
            if sys.exc_info()[0] is None:
                raise RuntimeError("worker cleanup failed")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worker", action="store_true")
    parser.add_argument("--shared-worker", action="store_true")
    parser.add_argument("--reply-fd", type=int)
    parser.add_argument("--atoms", type=int, choices=(48, 96), required=True)
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--basis-file", type=Path, required=True)
    parser.add_argument("--root", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--observer", type=Path)
    parser.add_argument(
        "--compare",
        choices=("incumbent", "angular", "materialized", "ao-reduction"),
        default="incumbent",
    )
    parser.add_argument("--candidate-variant", default="candidate")
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument("--feasibility", action="store_true")
    parsed = parser.parse_args()
    if parsed.worker:
        worker(parsed)
    else:
        main(parsed)
