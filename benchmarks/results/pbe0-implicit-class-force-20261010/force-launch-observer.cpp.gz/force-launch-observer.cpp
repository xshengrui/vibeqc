#include <cuda_runtime.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <unistd.h>

#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <cstring>

static std::atomic<unsigned long long> class_launches{};

/** Observe the actual new kernel without changing any launch argument or
 * issuing extra CUDA work. Sanitizer filters must not silently check zero
 * kernels; this receipt belongs to qualification only, never clean timing. */
extern "C" cudaError_t cudaLaunchKernel(const void* function, dim3 grid, dim3 block,
                                       void** arguments, size_t shared, cudaStream_t stream) {
  using Launch = cudaError_t (*)(const void*, dim3, dim3, void**, size_t, cudaStream_t);
  static auto launch = reinterpret_cast<Launch>(dlsym(RTLD_NEXT, "cudaLaunchKernel"));
  Dl_info information{};
  if (dladdr(function, &information) && information.dli_sname &&
      std::strstr(information.dli_sname, "direct_order_seven_force_kernel"))
    class_launches.fetch_add(1ULL, std::memory_order_relaxed);
  return launch(function, grid, block, arguments, shared, stream);
}

/** Child compiler processes may inherit LD_PRELOAD; record per-process counts
 * atomically and require actual checked-kernel launches in the parent. */
__attribute__((destructor)) static void publish() {
  const auto path = std::getenv("QC_FORCE_LAUNCH_LOG");
  if (!path) return;
  const auto descriptor = open(path, O_WRONLY | O_CREAT | O_APPEND, 0600);
  if (descriptor < 0) std::abort();
  char buffer[128];
  const auto length = std::snprintf(buffer, sizeof(buffer), "{\"pid\":%ld,\"class_launches\":%llu}\n",
                                    static_cast<long>(getpid()), class_launches.load());
  if (write(descriptor, buffer, length) != length) std::abort();
  close(descriptor);
}
