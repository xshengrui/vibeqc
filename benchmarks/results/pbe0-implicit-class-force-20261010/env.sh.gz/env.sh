#!/usr/bin/env bash
set -euo pipefail
export ROOT=/data/jzzeng/qc-angular-screen-20261009-d5a3173cc
export VARIANT="${VARIANT:-candidate}"
export SOURCE="$ROOT/$VARIANT"
export EVIDENCE="$ROOT/evidence"
export CUDA_PATH=/group/software/cuda-12.9.1
environment=/home/jzzeng/codes/wb97m-20261002
export PYTHON="$environment/gpu-env/bin/python"
export GENERATIVEQC_CCACHE="$environment/ccache/usr/bin/ccache"
export PATH="/data/jzzeng/qc-provider-1886-tools/cmake/bin:/data/jzzeng/qc-provider-1886-tools/bin:$environment/ccache/usr/bin:$CUDA_PATH/bin:$PATH"
export LD_PRELOAD="$CUDA_PATH/lib64/libcudart.so.12:$CUDA_PATH/lib64/libcublas.so.12:$CUDA_PATH/lib64/libcublasLt.so.12:$CUDA_PATH/lib64/libcusolver.so.11:$CUDA_PATH/lib64/libcusparse.so.12"
export GENERATIVEQC_NVCC=/data/jzzeng/qc-pbe0-integrated-base-20261006/.artifacts/bin/nvcc
export CUDACXX="$GENERATIVEQC_NVCC"
export CXX=/data/jzzeng/qc-pbe0-integrated-base-20261006/.artifacts/bin/c++
export CCACHE_DIR=/data/jzzeng/ccache CCACHE_BASEDIR="$SOURCE"
export GENERATIVEQC_STATIONARY_CACHE="$ROOT/stationary-cache"
export GENERATIVEQC_STATIONARY_CUDA_SPLIT_COMPILE_THREADS=8
export GENERATIVEQC_BENCHMARK_SOURCE="${BENCHMARK_SOURCE:-d5a3173cc-dirty-angular-precheck}"
export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=8 MKL_NUM_THREADS=8
export TMPDIR="$ROOT/tmp"
export PYTHONPATH="$SOURCE/python:$SOURCE"
export LD_LIBRARY_PATH="$SOURCE/build/cuda-release-sm120:$environment/ccache/usr/lib/x86_64-linux-gnu:$environment/gpu-env/lib/python3.13/site-packages/cutensor/lib:$CUDA_PATH/lib64"
export GENERATIVEQC_LIBRARY="$SOURCE/build/cuda-release-sm120/libgenerativeqc.so"
cd "$SOURCE"
