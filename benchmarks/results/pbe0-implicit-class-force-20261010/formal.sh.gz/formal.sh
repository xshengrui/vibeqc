#!/usr/bin/env bash
set -euo pipefail
export NEXT_VARIANT=candidate-force7-class-master-v1
unset VARIANT
source /data/jzzeng/qc-next-hotspot-20261009-125a4e33f/env-next.sh
: "${SLURM_JOB_ID:?}" "${CUDA_VISIBLE_DEVICES:?}"
export EVIDENCE="$ROOT/evidence/force7-class-master-v1/formal"
test -f "$ROOT/evidence/force7-class-master-v1/final/current-integration-completed.txt"
test -f "$ROOT/evidence/force7-class-master-v1/sanitizer/completed.txt"
test -f "$ROOT/evidence/force7-class-v1/diagnostic/verified-48.json"
test -f "$ROOT/evidence/force7-class-v1/diagnostic/verified-96.json"
test ! -e "$EVIDENCE/job.txt"
mkdir -p "$EVIDENCE"
export GENERATIVEQC_STATIONARY_BECKE_PROFILE=off
export GENERATIVEQC_DIRECT_PAIR_MATERIALIZED_DERIVATIVES=1
export GENERATIVEQC_BENCHMARK_SOURCE=88cfa7017-class-major-force7-hcore-formal
printf 'job=%s visibility=%s\n' "$SLURM_JOB_ID" "$CUDA_VISIBLE_DEVICES" > "$EVIDENCE/job.txt"
sha256sum "$GENERATIVEQC_LIBRARY" "$ROOT/evidence/force7-class-master-v1/paired-force7.py" \
  > "$EVIDENCE/identities.sha256"
for atoms in 48 96; do
  "$PYTHON" "$ROOT/evidence/force7-class-master-v1/paired-force7.py" --root "$ROOT" --atoms "$atoms" \
    --repeats 5 --basis-file "$SOURCE/benchmarks/results/pbe0-def2-svp-20261003/def2-svp-ho.json" \
    --reference "$ROOT/evidence/bulk-point-v7/reference-$atoms-retained-perf5.json" \
    --output "$EVIDENCE/paired-$atoms.json" > "$EVIDENCE/paired-$atoms.log" 2>&1
done
date -Iseconds > "$EVIDENCE/completed.txt"
