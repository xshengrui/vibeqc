#!/usr/bin/env bash
set -euo pipefail
export ROOT=/data/jzzeng/pbe0-mdj-source-reuse-20261010-b74815dba
export SOURCE="$ROOT/${MDJ_ARM:-baseline}"
environment=/home/jzzeng/codes/wb97m-20261002
export CUDA_PATH=/group/software/cuda-12.9.1
export PYTHON="$environment/gpu-env/bin/python"
export PATH="/data/jzzeng/qc-provider-1886-tools/cmake/bin:/data/jzzeng/qc-provider-1886-tools/bin:$environment/ccache/usr/bin:$CUDA_PATH/bin:$PATH"
export LD_PRELOAD="$CUDA_PATH/lib64/libcudart.so.12:$CUDA_PATH/lib64/libcublas.so.12:$CUDA_PATH/lib64/libcublasLt.so.12:$CUDA_PATH/lib64/libcusolver.so.11:$CUDA_PATH/lib64/libcusparse.so.12"
export CCACHE_DIR=/data/jzzeng/ccache CCACHE_BASEDIR="$SOURCE"
export GENERATIVEQC_STATIONARY_CACHE=/data/jzzeng/perf-pbe0-96-1985-20261006/cache/compiled
export GENERATIVEQC_STATIONARY_CUDA_SPLIT_COMPILE_THREADS=8
export GENERATIVEQC_CCACHE="$environment/ccache/usr/bin/ccache"
export GENERATIVEQC_NVCC="$CUDA_PATH/bin/nvcc" CUDACXX="$CUDA_PATH/bin/nvcc"
export NVCC_CCBIN=/usr/bin/g++
export PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=8 OPENBLAS_NUM_THREADS=8 MKL_NUM_THREADS=8
export TMPDIR="$ROOT/tmp"
export PYTHONPATH="$SOURCE/python:$SOURCE"
export LD_LIBRARY_PATH="$SOURCE/build/cuda-release-sm120:/data/jzzeng/issue1972-20261005/deps/lib:/data/jzzeng/cc-rebase-20261004/deps/lib:$environment/ccache/usr/lib/x86_64-linux-gnu:$environment/gpu-env/lib/python3.13/site-packages/cutensor/lib:$CUDA_PATH/lib64"
export GENERATIVEQC_LIBRARY="$SOURCE/build/cuda-release-sm120/libgenerativeqc.so"
export GENERATIVEQC_BENCHMARK_SOURCE=b74815dbad7d7bc6c2a052589a5e66c8089fc019
cd "$SOURCE"
