#!/usr/bin/env bash
set -euo pipefail
export MDJ_ARM=candidate-v4
source "$(dirname "$0")/env.sh"
export GENERATIVEQC_BENCHMARK_SOURCE=15bc69700
export GENERATIVEQC_MD_J_PROBE_CPP="$ROOT/md_j_resident_probe.cpp"
export PYTHONPATH="$ROOT:$PYTHONPATH"
: "${SLURM_JOB_ID:?Run through finite srun}"
: "${CUDA_VISIBLE_DEVICES:?Preserve scheduler visibility}"
out="$ROOT/evidence/full-pairs-v4-$SLURM_JOB_ID"
mkdir -p "$out"
cp "$ROOT/full-pairs-v4.sh" "$ROOT/env.sh" "$ROOT/test_md_j_normal_cuda.py" \
    "$ROOT/md_j_resident_probe.cpp" "$ROOT/md_j_resident_probe.py" "$out/"
trap 'status=$?; printf "{\"exit_code\":%s,\"job_id\":\"%s\"}\n" "$status" "$SLURM_JOB_ID" > "$out/outcome.json"' EXIT
scontrol show job "$SLURM_JOB_ID" > "$out/slurm.txt"
sha256sum "$GENERATIVEQC_LIBRARY" src/scf/cuda/direct_md_j.cu \
    src/scf/cuda/direct_jk.cpp python/generativeqc_compiler/integral/md_j_reciprocal_cuda.py \
    "$ROOT/test_md_j_normal_cuda.py" "$ROOT/md_j_resident_probe.cpp" \
    "$ROOT/md_j_resident_probe.py" > "$out/inputs.sha256"
unset MDJ_FIXED_COMPONENT_PROFILE GENERATIVEQC_MD_J_WORK_COUNTS
export GENERATIVEQC_TEST_MD_J_NORMAL=1
unset GENERATIVEQC_MD_J_RECIPROCAL
"$PYTHON" -m pytest "$ROOT/test_md_j_normal_cuda.py" -q > "$out/oracle.log" 2>&1
basis=benchmarks/results/pbe0-def2-svp-20261003/def2-svp-ho.json
for atoms in 3 48 96; do
    "$PYTHON" -m benchmarks.readme_pbe0 reference --atoms "$atoms" \
        --basis-file "$basis" --repeats 1 --output "$out/reference-$atoms.json" \
        > "$out/reference-$atoms.log" 2>&1
    index=0
    for mode in 0 default default 0 0 default; do
        if [[ "$mode" == default ]]; then unset GENERATIVEQC_MD_J_RECIPROCAL
        else export GENERATIVEQC_MD_J_RECIPROCAL="$mode"; fi
        "$PYTHON" -m benchmarks.readme_pbe0 native --atoms "$atoms" \
            --basis-file "$basis" --repeats 1 --reference "$out/reference-$atoms.json" \
            --output "$out/native-$atoms-$index-mode-$mode.json" \
            > "$out/native-$atoms-$index-mode-$mode.log" 2>&1
        index=$((index + 1))
    done
done
