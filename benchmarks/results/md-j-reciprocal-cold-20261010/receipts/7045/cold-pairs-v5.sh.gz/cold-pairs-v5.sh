#!/usr/bin/env bash
set -euo pipefail
export MDJ_ARM=candidate-v5
source "$(dirname "$0")/env.sh"
export GENERATIVEQC_BENCHMARK_SOURCE=82c166caca181fc0df51b1ff9378b972e3b1eba8
export GENERATIVEQC_MD_J_PROBE_CPP="$ROOT/md_j_resident_probe.cpp"
export PYTHONPATH="$ROOT:$PYTHONPATH"
: "${SLURM_JOB_ID:?Run through finite srun}"
: "${CUDA_VISIBLE_DEVICES:?Preserve scheduler visibility}"
out="$ROOT/evidence/cold-pairs-v5-$SLURM_JOB_ID"
mkdir -p "$out"
cp "$ROOT/cold-pairs-v5.sh" "$ROOT/cold-v3.py" "$ROOT/env.sh" \
    "$ROOT/test_md_j_normal_cuda.py" "$ROOT/md_j_resident_probe.cpp" \
    "$ROOT/md_j_resident_probe.py" "$out/"
trap 'status=$?; printf "{\"exit_code\":%s,\"job_id\":\"%s\"}\n" "$status" "$SLURM_JOB_ID" > "$out/outcome.json"' EXIT
scontrol show job "$SLURM_JOB_ID" > "$out/slurm.txt"
sha256sum "$GENERATIVEQC_LIBRARY" src/scf/cuda/direct_md_j.cu \
    src/scf/cuda/direct_jk.cpp python/generativeqc_compiler/integral/md_j_reciprocal_cuda.py \
    "$ROOT/test_md_j_normal_cuda.py" "$ROOT/md_j_resident_probe.cpp" \
    "$ROOT/md_j_resident_probe.py" > "$out/inputs.sha256"
unset MDJ_FIXED_COMPONENT_PROFILE MDJ_FIXED_J_HOST_PROFILE GENERATIVEQC_MD_J_WORK_COUNTS
export GENERATIVEQC_TEST_MD_J_NORMAL=1
unset GENERATIVEQC_MD_J_RECIPROCAL
"$PYTHON" -m pytest "$ROOT/test_md_j_normal_cuda.py" -q > "$out/oracle.log" 2>&1
compute-sanitizer --tool memcheck --error-exitcode 9 "$PYTHON" -m pytest \
    "$ROOT/test_md_j_normal_cuda.py" -q > "$out/memcheck.log" 2>&1
compute-sanitizer --tool racecheck --error-exitcode 9 "$PYTHON" -m pytest \
    "$ROOT/test_md_j_normal_cuda.py" -q -k work_census > "$out/racecheck.log" 2>&1
index=0
for mode in 0 default default 0 0 default; do
    if [[ "$mode" == default ]]; then unset GENERATIVEQC_MD_J_RECIPROCAL
    else export GENERATIVEQC_MD_J_RECIPROCAL="$mode"; fi
    "$PYTHON" "$ROOT/cold-v3.py" native \
        --reference /data/jzzeng/pbe0-master-cold-profile-20261010-985caaf01/results/6989/reference-0.json \
        --output "$out/cold-$index-mode-$mode.json" > "$out/cold-$index-mode-$mode.log" 2>&1
    index=$((index + 1))
done
