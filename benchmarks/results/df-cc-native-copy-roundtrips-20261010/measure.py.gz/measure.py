"""Frozen pair-enabled baseline versus copy-elided complete FP64 endpoints."""

from __future__ import annotations

import hashlib
import json
import math
import os
import statistics
import struct
import subprocess
import time
from pathlib import Path

ROOT = Path('/data/jzzeng/qc-cc-copy-roundtrips-20261010')
PREVIOUS = Path('/data/jzzeng/qc-cc-spectator-pairs-20261010')
SOURCE = PREVIOUS / 'production-source'
DEPS = Path('/data/jzzeng/issue1972-20261005/deps')
OUT = ROOT / 'matched-results'
OUT.mkdir(exist_ok=True)
INPUT = SOURCE / 'benchmarks/results/rccsd-diis-ring-1900/ethane230.input'
ORACLE = SOURCE / 'benchmarks/results/df-lambda-cost-2136-20261009/oracle-energy.json'
oracle = json.loads(ORACLE.read_text())
directories = {'base': PREVIOUS / 'candidate-admission', 'candidate': ROOT / 'candidate'}


def checksum(path: Path) -> str:
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


provenance = {
    'parent': (ROOT / 'parent.txt').read_text().strip(),
    'master_observed_before_measurement': 'ee0ca19d5cade2eddcbd05585af2739ebe3f7619',
    'qualification_base': 'frozen pair-enabled PR #2178; not latest-master qualification',
    'slurm_job': os.environ['SLURM_JOB_ID'],
    'visibility': os.environ['CUDA_VISIBLE_DEVICES'],
    'device': json.loads(subprocess.check_output([str(PREVIOUS / 'visible-device')], text=True)),
    'input_sha256': checksum(INPUT),
    'oracle_sha256': checksum(ORACLE),
    'source_archives': {
        name: checksum(ROOT / name) for name in ('parent.tar.gz', 'overlay.tar.gz')
    },
    'libraries': {name: checksum(directory / 'libgenerativeqc.so') for name, directory in directories.items()},
    'executables': {name: checksum(directory / 'endpoint') for name, directory in directories.items()},
    'timing_boundary': 'fresh process: native molecular RHF, DF source, CCSD including admission/projection, independent expanded replay, FP64 (T), and owner teardown',
    'forces_requested': False,
    'precision': 'FP64, pedantic matrix GEMMs, unchanged ascending-Q accumulation',
    'packed_diis': False,
    'copy_elisions_per_primary_q_tile': 6,
}
(OUT / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
controls = ['1', '1', '0', '1', '8', '8', '8', '0', '0', '2', '1', '30', '0', '0', '0']
invariants = (
    'ccsd_iterations', 'ccsd_evaluations', 'ccsd_q_batch_size', 'ccsd_q_slices',
    'ccsd_q_tiles', 'ccsd_accumulation_calls', 'ccsd_accumulation_bytes',
    'reference_iterations', 'derived_d2_iteration_evaluations', 'ccsd_setup_h2d_bytes',
    'ccsd_gemm_calls', 'ccsd_gemm_summands', 'ccsd_contraction_terms',
    'ccsd_capacity', 'ccsd_packing_bytes', 'ccsd_pair_evaluations',
    'ccsd_pair_refusals', 'ccsd_pair_projection_calls',
)
observations = []
for sample, variant in enumerate(('base', 'candidate', 'candidate', 'base')):
    output = OUT / f'{sample:02d}-{variant}.json'
    directory = directories[variant]
    command = [str(directory / 'endpoint'), str(INPUT), str(output), *controls]
    environment = dict(os.environ)
    environment['LD_LIBRARY_PATH'] = ':'.join((str(directory), str(DEPS / 'lib'), '/group/software/cuda-12.9.1/lib64'))
    environment.pop('GENERATIVEQC_DF_PROGRESS_TRACE', None)
    print(f'starting {sample} {variant}', flush=True)
    started = time.perf_counter()
    with output.with_suffix('.log').open('w') as stream:
        subprocess.run(command, env=environment, stdout=stream, stderr=subprocess.STDOUT, check=True, timeout=420)
    wall = time.perf_counter() - started
    record = json.loads(output.read_text())
    assert record['nbf'] == oracle['nocc'] + oracle['nvir']
    assert record['naux'] == oracle['naux']
    assert record['ccsd_q_slices'] == record['naux'] * (record['ccsd_evaluations'] + 1)
    assert record['ccsd_replay_matrix_gemm'] == 1
    assert record['ccsd_occupied_pairs'] == 1
    assert record['ccsd_pair_evaluations'] == record['ccsd_evaluations'] == 38
    assert record['ccsd_pair_refusals'] == 0
    gates = {
        'total_energy_error': abs(record['total_energy'] - oracle['total_energy']),
        'triples_energy_error': abs(record['triples_energy'] - oracle['triples_energy']),
        'physical_replay_r1': record['ccsd_replay_r1_max'],
        'physical_replay_r2': record['ccsd_replay_r2_max'],
    }
    gates['passed'] = (
        gates['total_energy_error'] <= 1e-8
        and gates['triples_energy_error'] <= 1e-10
        and max(gates['physical_replay_r1'], gates['physical_replay_r2']) <= 1e-10
    )
    assert gates['passed'], gates
    for key in ('native_seconds', 'reference_seconds', 'source_seconds', 'ccsd_seconds', 'triples_seconds'):
        assert math.isfinite(record[key]) and record[key] >= 0
    control = observations[0]['record'] if observations else record
    assert all(record[key] == control[key] for key in invariants), 'semantic work or solver trajectory changed'
    assert all(struct.pack('d', record[key]) == struct.pack('d', control[key]) for key in ('total_energy', 'triples_energy')), 'endpoint energy bits changed'
    primary_tiles = record['ccsd_evaluations'] * math.ceil(record['naux'] / record['ccsd_q_batch_size'])
    assert primary_tiles == 2318
    expected_delta = 6 * primary_tiles if variant == 'candidate' else 0
    assert control['ccsd_q_operations'] - record['ccsd_q_operations'] == expected_delta == (13908 if variant == 'candidate' else 0)
    observations.append({'variant': variant, 'command': command, 'process_wall_seconds': wall, 'record': record, 'gates': gates})
    (OUT / 'samples.json').write_text(json.dumps(observations, indent=2) + '\n')
    print(variant, wall, record['ccsd_seconds'], record['ccsd_q_operations'], flush=True)

keys = (
    'native_seconds', 'reference_seconds', 'source_seconds', 'ccsd_seconds',
    'triples_seconds', 'ccsd_iteration_seconds', 'ccsd_replay_seconds',
    'ccsd_diis_seconds', 'ccsd_update_seconds', 'ccsd_packing_bytes',
    'ccsd_capacity', 'ccsd_q_operations', 'ccsd_gemm_calls', 'ccsd_gemm_summands',
    'ccsd_contraction_terms',
)
medians = {
    variant: {key: statistics.median(item['record'][key] for item in observations if item['variant'] == variant) for key in keys}
    for variant in directories
}
for variant, values in medians.items():
    values['complete_process_wall_seconds'] = statistics.median(item['process_wall_seconds'] for item in observations if item['variant'] == variant)
avoided_logical_bytes = 4 * 8 * 3 * oracle['nocc'] ** 2 * oracle['nvir'] ** 2 * oracle['naux'] * 38
assert avoided_logical_bytes == 7042781551104
summary = {
    'provenance': provenance,
    'medians': medians,
    'complete_process_wall_speedup': medians['base']['complete_process_wall_seconds'] / medians['candidate']['complete_process_wall_seconds'],
    'ccsd_speedup': medians['base']['ccsd_seconds'] / medians['candidate']['ccsd_seconds'],
    'all_scientific_gates_passed': True,
    'all_endpoint_energy_bits_identical': True,
    'all_work_deltas_exact': True,
    'avoided_logical_copy_read_write_bytes': avoided_logical_bytes,
    'traffic_interpretation': 'logical native load/store bytes, not measured DRAM traffic',
    'interpretation': 'two fresh samples per selection in ABBA order; scoped energy-only endpoint observation, not formal/global performance or force promotion',
}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2), flush=True)
