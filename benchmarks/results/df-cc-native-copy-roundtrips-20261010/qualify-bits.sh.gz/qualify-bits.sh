#!/usr/bin/env bash
set -euo pipefail
root=/data/jzzeng/qc-cc-copy-roundtrips-20261010
source="$root/source"
deps=/data/jzzeng/issue1972-20261005/deps
export PATH="$deps/bin:/group/software/cuda-12.9.1/bin:/usr/bin:/home/jzzeng/miniconda3/bin:$PATH"
export LD_LIBRARY_PATH="$deps/lib:/group/software/cuda-12.9.1/lib64:${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$source/python:$source:$deps"
export CCACHE_BASEDIR="$source"
export GENERATIVEQC_DF_CC_CUDA_TEST=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
printf '%s\n' "$SLURM_JOB_ID" "$CUDA_VISIBLE_DEVICES" > "$root/bits-allocation.txt"
cd "$source"
/home/jzzeng/miniconda3/bin/python -m pytest -q tests/python/test_tensor_native_copy_roundtrips.py \
  -k cuda --basetemp "$root/pytest-bits" > "$root/bits-tests.log" 2>&1
probe=$(find "$root/pytest-bits" -type f -name probe -print -quit)
test -n "$probe"
compute-sanitizer --tool memcheck --error-exitcode 99 "$probe" > "$root/bits-memcheck.log" 2>&1
