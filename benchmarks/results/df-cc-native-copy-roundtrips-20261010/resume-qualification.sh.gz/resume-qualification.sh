#!/usr/bin/env bash
set -euo pipefail
root=/data/jzzeng/qc-cc-copy-roundtrips-20261010
baseline=/data/jzzeng/qc-cc-spectator-pairs-20261010/candidate-admission
deps=/data/jzzeng/issue1972-20261005/deps
source="$root/source"
output="$root/candidate"
export PATH="$deps/bin:/group/software/cuda-12.9.1/bin:/usr/bin:/home/jzzeng/miniconda3/bin:$PATH"
export LD_LIBRARY_PATH="$deps/lib:/group/software/cuda-12.9.1/lib64:${LD_LIBRARY_PATH:-}"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export CCACHE_BASEDIR="$source"
cd "$source"
printf '%s\n' "$SLURM_JOB_ID" "$CUDA_VISIBLE_DEVICES" > "$root/qualify-allocation.txt"
trap 'result=$?; if ((result != 0)); then printf "qualification-failed:%s\n" "$result" > "$root/status.txt"; fi; ccache --show-stats > "$root/qualification-cache-after.txt"' EXIT
printf '%s\n' comparing > "$root/status.txt"
artifacts=(
  generated_rccsd_cpu.hpp generated_rccsd_cuda.cu
  generated_df_ccsd_cpu.hpp generated_df_ccsd_cuda.cu generated_df_ccsd_cuda.cuh
  generated_df_ccsd_core_cpu.hpp generated_df_ccsd_core_cuda.cu generated_df_ccsd_core_cuda.cuh
  generated_df_ccsd_hoisted_cpu.hpp generated_df_ccsd_hoisted_cuda.cu generated_df_ccsd_hoisted_cuda.cuh
  generated_df_ccsd_spectator_pairs_cpu.hpp
)
for artifact in "${artifacts[@]}"; do
  cmp "$output/generated/$artifact" "$baseline/generated/$artifact"
  sha256sum "$output/generated/$artifact"
done > "$root/unchanged-generated.sha256"
printf '%s\n' linking-endpoint > "$root/status.txt"
ccache /usr/bin/g++ -std=c++20 -O2 -DGENERATIVEQC_HAS_CUDA=1 \
  -Iinclude -Isrc -I/group/software/cuda-12.9.1/include \
  -c benchmarks/df_ccsdt_force_endpoint.cpp -o "$output/endpoint.o"
/usr/bin/g++ "$output/endpoint.o" "$output/libgenerativeqc.so" \
  -Wl,-rpath,"$output" -o "$output/endpoint"
sha256sum "$output/libgenerativeqc.so" "$output/endpoint" > "$output/binaries.sha256"
printf '%s\n' qualifying > "$root/status.txt"
export LD_LIBRARY_PATH="$output:$deps/lib:/group/software/cuda-12.9.1/lib64"
export PYTHONPATH="$source/python:$source:$deps"
export GENERATIVEQC_DF_CC_CUDA_TEST=1 GENERATIVEQC_DF_CC_USE_LIBRARY=1
export GENERATIVEQC_LIBRARY="$output/libgenerativeqc.so"
/home/jzzeng/miniconda3/bin/python -m pytest -q tests/python/test_df_cc_native_solver.py \
  -k 'cuda and (occupied_pairs or single_occupied_block or expanded_matrix_replay or auxiliary_tiles)' \
  --basetemp "$root/pytest-library" > "$root/library-tests.log" 2>&1
unset GENERATIVEQC_DF_CC_USE_LIBRARY
/home/jzzeng/miniconda3/bin/python -m pytest -q tests/python/test_df_cc_spectator_pairs_codegen.py \
  -k cuda --basetemp "$root/pytest-actions" > "$root/action-tests.log" 2>&1
printf '%s\n' qualified > "$root/status.txt"
