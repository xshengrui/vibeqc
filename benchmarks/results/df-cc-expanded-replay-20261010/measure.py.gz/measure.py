"""Matched complete endpoints with an external oracle and exact work accounting."""

from __future__ import annotations

import hashlib
import json
import math
import os
import statistics
import subprocess
import time
from math import prod
from pathlib import Path

from tools.generate_df_ccsd_native import packed_replay_program, programs
from tools.generate_rccsd_native import _packed_matrix_gemm

ROOT = Path("/data/jzzeng/qc-cc-replay-20261010")
SOURCE = ROOT / "source"
DEPS = Path("/data/jzzeng/issue1972-20261005/deps")
OUT = ROOT / "results"
OUT.mkdir(exist_ok=True)


def checksum(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


input_path = SOURCE / "benchmarks/results/rccsd-diis-ring-1900/ethane230.input"
oracle_path = (
    SOURCE / "benchmarks/results/df-lambda-cost-2136-20261009/oracle-energy.json"
)
oracle = json.loads(oracle_path.read_text())
nocc, nvir = oracle["nocc"], oracle["nvir"]
original, packed = programs("cuda")["virtual"], packed_replay_program()
gemms = [node for node in packed.live_nodes if _packed_matrix_gemm(node) is not None]
replay_work = {
    "gemm_calls": len(gemms),
    "gemm_summands": sum(
        prod(
            {
                label: nocc if index.space.kind == "occupied" else nvir
                for child, labels in zip(node.inputs, node.attrs["labels"], strict=True)
                for label, index in zip(labels, child.spec.indices, strict=True)
            }.values()
        )
        for node in gemms
    ),
    "operation_delta": sum(node.op != "input" for node in packed.live_nodes)
    - sum(node.op != "input" for node in original.live_nodes),
    "packing_bytes": 16
    * sum(
        prod(
            nocc if index.space.kind == "occupied" else nvir
            for index in node.spec.indices
        )
        for node in packed.live_nodes
        if node.op == "transpose"
    ),
    "contraction_terms_saved": nocc * nvir * nvir,
}
provenance = {
    "base_commit": (ROOT / "base-commit.txt").read_text().strip(),
    "slurm_job": os.environ["SLURM_JOB_ID"],
    "visibility": os.environ["CUDA_VISIBLE_DEVICES"],
    "device": subprocess.check_output(
        [
            "nvidia-smi",
            "--id=" + os.environ["CUDA_VISIBLE_DEVICES"],
            "--query-gpu=uuid,name,driver_version,power.limit",
            "--format=csv,noheader",
        ],
        text=True,
    ).strip(),
    "input_sha256": checksum(input_path),
    "oracle_sha256": checksum(oracle_path),
    "measured_patch_sha256": checksum(ROOT / "candidate.patch"),
    "baseline_timer_patch_sha256": checksum(ROOT / "base-timers.patch"),
    "libraries": {
        variant: checksum(ROOT / variant / "libgenerativeqc.so")
        for variant in ("base", "candidate")
    },
    "executables": {
        variant: checksum(ROOT / variant / "endpoint")
        for variant in ("base", "candidate")
    },
    "timing_boundary": "native molecular RHF + DF source + CCSD + independent expanded physical replay + FP64 (T), including phase-owner teardown; process wall also includes startup and final cleanup",
    "forces_requested": False,
    "precision": "FP64, pedantic matrix provider, unchanged Q accumulation order",
    "replay_work_per_q": replay_work,
}
(OUT / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
controls = ["1", "1", "0", "1", "8", "8", "8", "0", "0", "2", "1", "30", "0", "0", "1"]
invariant_work = (
    "ccsd_iterations",
    "ccsd_evaluations",
    "ccsd_q_batch_size",
    "ccsd_q_slices",
    "ccsd_q_tiles",
    "ccsd_accumulation_calls",
    "ccsd_accumulation_bytes",
    "reference_iterations",
    "derived_d2_iteration_evaluations",
    "ccsd_setup_h2d_bytes",
)
adjustments = {
    "ccsd_gemm_calls": replay_work["gemm_calls"],
    "ccsd_gemm_summands": replay_work["gemm_summands"],
    "ccsd_q_operations": replay_work["operation_delta"],
    "ccsd_packing_bytes": replay_work["packing_bytes"],
    "ccsd_contraction_terms": -replay_work["contraction_terms_saved"],
}
observations = []
for sample, variant in enumerate(("base", "candidate", "candidate", "base")):
    output = OUT / f"{sample:02d}-{variant}.json"
    command = [
        str(ROOT / variant / "endpoint"),
        str(input_path),
        str(output),
        *controls,
    ]
    environment = dict(os.environ)
    environment["LD_LIBRARY_PATH"] = ":".join(
        (str(ROOT / variant), str(DEPS / "lib"), "/group/software/cuda-12.9.1/lib64")
    )
    environment.pop("GENERATIVEQC_DF_PROGRESS_TRACE", None)
    print(f"starting {sample} {variant}", flush=True)
    started = time.perf_counter()
    with output.with_suffix(".log").open("w") as log:
        subprocess.run(
            command,
            env=environment,
            stdout=log,
            stderr=subprocess.STDOUT,
            timeout=900,
            check=True,
        )
    wall = time.perf_counter() - started
    record = json.loads(output.read_text())
    assert record["nbf"] == nocc + nvir and record["naux"] == oracle["naux"]
    replay_slices = (
        record["ccsd_q_slices"] - record["naux"] * record["ccsd_evaluations"]
    )
    assert replay_slices == record["naux"], (
        "missing or repeated original physical audit"
    )
    assert record.get("ccsd_replay_matrix_gemm", 0) == (variant == "candidate")
    gates = {
        "total_energy_error": abs(record["total_energy"] - oracle["total_energy"]),
        "triples_energy_error": abs(
            record["triples_energy"] - oracle["triples_energy"]
        ),
        "physical_replay_r1": record["ccsd_replay_r1_max"],
        "physical_replay_r2": record["ccsd_replay_r2_max"],
    }
    gates["passed"] = (
        gates["total_energy_error"] <= 1e-8
        and gates["triples_energy_error"] <= 1e-10
        and max(gates["physical_replay_r1"], gates["physical_replay_r2"]) <= 1e-10
    )
    for key in (
        "native_seconds",
        "reference_seconds",
        "source_seconds",
        "ccsd_seconds",
        "triples_seconds",
    ):
        assert math.isfinite(record[key]) and record[key] >= 0
    observations.append(
        {
            "variant": variant,
            "command": command,
            "process_wall_seconds": wall,
            "record": record,
            "gates": gates,
        }
    )
    (OUT / "samples.json").write_text(json.dumps(observations, indent=2) + "\n")
    assert gates["passed"], gates
    if sample:
        control = observations[0]["record"]
        assert all(record[key] == control[key] for key in invariant_work), (
            "solver trajectory changed"
        )
        for key, adjustment in adjustments.items():
            expected = control[key] + (
                replay_slices * adjustment if variant == "candidate" else 0
            )
            assert record[key] == expected, (key, record[key], expected)
        assert abs(record["total_energy"] - control["total_energy"]) <= 2e-11
    print(
        variant,
        record["native_seconds"],
        record["ccsd_seconds"],
        record["ccsd_replay_seconds"],
        flush=True,
    )
keys = (
    "native_seconds",
    "reference_seconds",
    "source_seconds",
    "ccsd_seconds",
    "triples_seconds",
    "ccsd_iteration_seconds",
    "ccsd_replay_seconds",
    "ccsd_diis_seconds",
    "ccsd_update_seconds",
    "ccsd_packing_bytes",
    "ccsd_capacity",
    "ccsd_q_operations",
    "ccsd_gemm_calls",
    "ccsd_gemm_summands",
    "ccsd_contraction_terms",
)
medians = {
    variant: {
        key: statistics.median(
            item["record"][key] for item in observations if item["variant"] == variant
        )
        for key in keys
    }
    for variant in ("base", "candidate")
}
for variant in medians:
    medians[variant]["complete_process_wall_seconds"] = statistics.median(
        item["process_wall_seconds"]
        for item in observations
        if item["variant"] == variant
    )
summary = {
    "provenance": provenance,
    "medians": medians,
    "native_speedup": medians["base"]["native_seconds"]
    / medians["candidate"]["native_seconds"],
    "complete_process_wall_speedup": medians["base"]["complete_process_wall_seconds"]
    / medians["candidate"]["complete_process_wall_seconds"],
    "ccsd_speedup": medians["base"]["ccsd_seconds"]
    / medians["candidate"]["ccsd_seconds"],
    "all_scientific_gates_passed": True,
    "all_work_deltas_exact": True,
    "interpretation": "four preserved fresh-process samples, no broad performance claim; work deltas follow only original replay packing/CSE, while the complete solver trajectory and physical Q scope match",
}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2), flush=True)
