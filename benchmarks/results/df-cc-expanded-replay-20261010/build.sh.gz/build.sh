#!/usr/bin/env bash
set -euo pipefail
root=/data/jzzeng/qc-cc-replay-20261010
deps=/data/jzzeng/issue1972-20261005/deps
export PATH="$deps/bin:/group/software/cuda-12.9.1/bin:/usr/bin:/home/jzzeng/miniconda3/bin:$PATH"
export LD_LIBRARY_PATH="$deps/lib:/group/software/cuda-12.9.1/lib64:${LD_LIBRARY_PATH:-}"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export CCACHE_BASEDIR="$root/source"
cd "$root/source"
tar -xzf "$root/base-source.tar.gz"
ccache --version > "$root/compiler-cache-version.txt"
ccache --show-stats > "$root/compiler-cache-before.txt"
trap 'ccache --show-stats > "$root/compiler-cache-after.txt"' EXIT
cmake -S . -B build-cuda -GNinja -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_CXX_COMPILER=/usr/bin/g++ -DCMAKE_C_COMPILER=/usr/bin/gcc \
  -DPython3_EXECUTABLE=/home/jzzeng/miniconda3/bin/python \
  -DGENERATIVEQC_ENABLE_CUDA=ON -DCMAKE_CUDA_ARCHITECTURES=120 \
  -DGENERATIVEQC_BUILD_TESTS=OFF -DGENERATIVEQC_BUILD_CLI=OFF \
  -DGENERATIVEQC_ENABLE_AOT_SHELLS=ON -DGENERATIVEQC_AOT_PROFILE=portable_cuda \
  -DGENERATIVEQC_BUNDLE_XTB_OPENBLAS=OFF \
  -DCMAKE_CXX_COMPILER_LAUNCHER=ccache -DCMAKE_CUDA_COMPILER_LAUNCHER=ccache \
  > "$root/base/configure.log" 2>&1
git apply "$root/base-timers.patch"
for variant in base candidate; do
  if [[ "$variant" == candidate ]]; then
    git apply -R "$root/base-timers.patch"
    git apply "$root/candidate.patch"
    cp "$root/test_df_cc_matrix_replay.py" tests/python/
  fi
  printf '%s\n' building > "$root/$variant/status.txt"
  cmake --build build-cuda --target generativeqc -j8 > "$root/$variant/build.log" 2>&1
  cp build-cuda/libgenerativeqc.so "$root/$variant/"
  ln -sfn libgenerativeqc.so "$root/$variant/libgenerativeqc.so.0"
  cp -a build-cuda/generated "$root/$variant/"
  ccache /usr/bin/g++ -std=c++20 -O2 -DGENERATIVEQC_HAS_CUDA=1 \
    -Iinclude -Isrc -I/group/software/cuda-12.9.1/include \
    -c benchmarks/df_ccsdt_force_endpoint.cpp -o "$root/$variant/endpoint.o"
  /usr/bin/g++ "$root/$variant/endpoint.o" "$root/$variant/libgenerativeqc.so" \
    -Wl,-rpath,"$root/$variant" -o "$root/$variant/endpoint"
  sha256sum "$root/$variant/libgenerativeqc.so" "$root/$variant/endpoint" \
    > "$root/$variant/binaries.sha256"
  printf '%s\n' complete > "$root/$variant/status.txt"
done
