#!/usr/bin/env bash
set -euo pipefail
root=/data/jzzeng/qc-cc-replay-20261010
deps=/data/jzzeng/issue1972-20261005/deps
export PATH="$deps/bin:/group/software/cuda-12.9.1/bin:/usr/bin:/home/jzzeng/miniconda3/bin:$PATH"
export LD_LIBRARY_PATH="$root/candidate:$deps/lib:/group/software/cuda-12.9.1/lib64:${LD_LIBRARY_PATH:-}"
export PYTHONPATH="$root/source/python:$root/source:$deps"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export GENERATIVEQC_LIBRARY="$root/candidate/libgenerativeqc.so"
export GENERATIVEQC_DF_CC_CUDA_TEST=1 GENERATIVEQC_DF_CC_USE_LIBRARY=1
cd "$root/source"
cp "$root/test_df_cc_native_solver.py" tests/python/test_df_cc_native_solver.py
printf '%s\n' "$SLURM_JOB_ID" "$CUDA_VISIBLE_DEVICES" > "$root/gpu-allocation.txt"
/home/jzzeng/miniconda3/bin/python -m pytest -q tests/python/test_df_cc_native_solver.py -k '(cuda and (expanded_matrix_replay or early_auxiliary_overflow or prepare_and_core_overflow)) or generated_auxiliary' > "$root/gpu-tests.log" 2>&1
/home/jzzeng/miniconda3/bin/python "$root/measure.py" > "$root/matched.log" 2>&1
